import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ui-DZEswU5A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CAUSES = [
	"Shelter",
	"Food",
	"Health",
	"Disaster",
	"Hygiene"
];
var PROOF_LABEL = {
	photo: "Time-stamped photo with GPS",
	carrier: "Carrier delivery confirmation",
	receipt: "Signed provider receipt"
};
function splitAmount(amount) {
	const cents = Math.round(amount * 100);
	const feeCents = Math.round(cents * .01);
	return {
		fee: feeCents / 100,
		vendor: (cents - feeCents) / 100
	};
}
function money(amount) {
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		minimumFractionDigits: 2
	}).format(amount);
}
function fakeHash(seed) {
	let x = 2166136261;
	for (let i = 0; i < seed.length; i++) {
		x ^= seed.charCodeAt(i);
		x = Math.imul(x, 16777619);
	}
	let out = "";
	for (let i = 0; i < 8; i++) {
		x = Math.imul(x ^ x >>> 13, 1274126177) >>> 0;
		out += x.toString(16).padStart(8, "0");
	}
	return out;
}
function shortHash(hash) {
	return `${hash.slice(0, 8)}…${hash.slice(-6)}`;
}
function maskEmail(email) {
	const [user, domain] = email.split("@");
	if (!user || !domain) return "requested";
	return `${user.slice(0, 1)}•••@${domain}`;
}
function norm(value) {
	return value.trim().toLowerCase().replace(/\s+/g, " ");
}
function formatWhen(ts) {
	return new Intl.DateTimeFormat("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	}).format(ts);
}
function escrowBase(partial) {
	const parts = splitAmount(partial.amount);
	return {
		donorTag: "archive",
		vendorShare: parts.vendor,
		feeShare: parts.fee,
		txCreate: fakeHash(`${partial.id}:create`),
		...partial
	};
}
function createSeed() {
	return {
		charities: [
			{
				id: "ch-harbor",
				name: "Harbor Light Shelter",
				ein: "04-3182204",
				city: "Boston",
				state: "MA",
				cause: "Shelter",
				wallet: "rHb9HarborLight4rj91VRWn96DkukG4bw",
				blurb: "Overnight beds and a supply closet that is restocked only when a donor funds a listed item.",
				verified: true
			},
			{
				id: "ch-rio",
				name: "Rio Mesa Food Bank",
				ein: "74-2209183",
				city: "Austin",
				state: "TX",
				cause: "Food",
				wallet: "rRioMesaFoodBank91VRWn96DkukG4bwd",
				blurb: "A pantry that buys rice, protein, and produce from named wholesalers. No general fund.",
				verified: true
			},
			{
				id: "ch-molar",
				name: "Bright Molar Kids Clinic",
				ein: "86-4419027",
				city: "Phoenix",
				state: "AZ",
				cause: "Health",
				wallet: "rBrightMolarKids86VRWn96DkukG4bwdty",
				blurb: "Pediatric dental visits for families without coverage. The clinic is the vendor and is paid directly.",
				verified: true
			},
			{
				id: "ch-lake",
				name: "Lakeshore Family House",
				ein: "36-2901148",
				city: "Chicago",
				state: "IL",
				cause: "Hygiene",
				wallet: "rLakeshoreFamily36VRWn96DkukG4bwdt",
				blurb: "Family rooms for people leaving unsafe housing. Baseline goods can later move to a monthly subscription escrow.",
				verified: true
			},
			{
				id: "ch-tide",
				name: "Tidewater Relief",
				ein: "54-7712033",
				city: "Norfolk",
				state: "VA",
				cause: "Disaster",
				wallet: "rTidewaterRelief54VRWn96DkukG4bwdty",
				blurb: "Storm response supplies shipped to a verified warehouse, then proved with a carrier confirmation.",
				verified: true
			}
		],
		needs: [
			{
				id: "n-water",
				charityId: "ch-harbor",
				title: "4 cases of drinking water",
				detail: "The worked example from the whitepaper. One donor funds this exact item.",
				price: 20,
				vendor: "Northline Wholesale",
				vendorWallet: "rNorthlineWholesaleVRWn96DkukG4b"
			},
			{
				id: "n-kits",
				charityId: "ch-harbor",
				title: "20 hygiene kits",
				detail: "Soap, toothpaste, and a towel, packed for new arrivals.",
				price: 86,
				vendor: "CleanStart Supply",
				vendorWallet: "rCleanStartSupplyVRWn96DkukG4bw"
			},
			{
				id: "n-blankets",
				charityId: "ch-harbor",
				title: "12 wool blankets",
				detail: "Waiting on the shelter to submit the merchant invoice and a delivery photo.",
				price: 144,
				vendor: "Hearth Textile Co.",
				vendorWallet: "rHearthTextileCoVRWn96DkukG4bwd"
			},
			{
				id: "n-rice",
				charityId: "ch-rio",
				title: "40 lb of rice",
				detail: "A staple sack for the week’s pantry build.",
				price: 32,
				vendor: "Gulf Grain Co-op",
				vendorWallet: "rGulfGrainCoopVRWn96DkukG4bwdty"
			},
			{
				id: "n-cans",
				charityId: "ch-rio",
				title: "Case of canned protein",
				detail: "Invoice and carrier confirmation are in. The oracle has not run yet.",
				price: 48,
				vendor: "Pantry Line Foods",
				vendorWallet: "rPantryLineFoodsVRWn96DkukG4bwd"
			},
			{
				id: "n-clean",
				charityId: "ch-molar",
				title: "Pediatric cleaning",
				detail: "One appointment. Proof was a signed provider record.",
				price: 75,
				vendor: "Bright Molar Clinic",
				vendorWallet: "rBrightMolarClinicVRWn96DkukG4b"
			},
			{
				id: "n-seal",
				charityId: "ch-molar",
				title: "Sealants for 6 children",
				detail: "A kit plus chair time. The provider is paid only after the signed record.",
				price: 120,
				vendor: "Bright Molar Clinic",
				vendorWallet: "rBrightMolarClinicVRWn96DkukG4b"
			},
			{
				id: "n-diaper",
				charityId: "ch-lake",
				title: "Diapers, size 4, one pallet",
				detail: "Baseline stock. A future module would renew this every 30 days.",
				price: 210,
				vendor: "Little Steps Wholesale",
				vendorWallet: "rLittleStepsWholesaleVRWn96Dkuk"
			},
			{
				id: "n-formula",
				charityId: "ch-lake",
				title: "Infant formula, 8 cases",
				detail: "Released to the wholesaler after the delivery photo matched the dock.",
				price: 96,
				vendor: "Hearthwell Nutrition",
				vendorWallet: "rHearthwellNutritionVRWn96DkukG"
			},
			{
				id: "n-tarp",
				charityId: "ch-tide",
				title: "Emergency tarp kits × 10",
				detail: "Still open. Built for a fast merchant order once a donor locks the price.",
				price: 150,
				vendor: "Shoreline Field Supply",
				vendorWallet: "rShorelineFieldSupplyVRWn96Dkuk"
			},
			{
				id: "n-tabs",
				charityId: "ch-tide",
				title: "Water purification tablets",
				detail: "A small gift that still cleared the two-proof rule.",
				price: 28,
				vendor: "ClearCurrent Labs",
				vendorWallet: "rClearCurrentLabsVRWn96DkukG4bw"
			}
		],
		escrows: [
			escrowBase({
				id: "esc-kits",
				needId: "n-kits",
				charityId: "ch-harbor",
				amount: 86,
				status: "released",
				createdAt: Date.parse("2026-10-02T15:00:00Z"),
				finishedAt: Date.parse("2026-10-04T18:10:00Z"),
				txFinish: fakeHash("esc-kits:finish"),
				invoice: {
					vendor: "CleanStart Supply",
					lines: "20 hygiene kits",
					total: 86
				},
				proof: {
					kind: "photo",
					note: "Dock photo at Harbor Light, GPS matched the shelter, cartons sealed.",
					where: "Boston, MA"
				},
				oracle: {
					invoiceOk: true,
					deliveryOk: true,
					notes: ["Vendor, line, and price matched the funded need.", "Photo metadata accepted."]
				}
			}),
			escrowBase({
				id: "esc-rice",
				needId: "n-rice",
				charityId: "ch-rio",
				amount: 32,
				status: "released",
				createdAt: Date.parse("2026-10-04T15:00:00Z"),
				finishedAt: Date.parse("2026-10-05T16:00:00Z"),
				txFinish: fakeHash("esc-rice:finish"),
				invoice: {
					vendor: "Gulf Grain Co-op",
					lines: "40 lb rice",
					total: 32
				},
				proof: {
					kind: "carrier",
					note: "Carrier marked delivered to the pantry loading door.",
					where: "Austin, TX"
				},
				oracle: {
					invoiceOk: true,
					deliveryOk: true,
					notes: ["Invoice matched.", "Carrier confirmation accepted."]
				}
			}),
			escrowBase({
				id: "esc-clean",
				needId: "n-clean",
				charityId: "ch-molar",
				amount: 75,
				status: "released",
				createdAt: Date.parse("2026-10-06T15:00:00Z"),
				finishedAt: Date.parse("2026-10-06T21:00:00Z"),
				txFinish: fakeHash("esc-clean:finish"),
				invoice: {
					vendor: "Bright Molar Clinic",
					lines: "Pediatric cleaning",
					total: 75
				},
				proof: {
					kind: "receipt",
					note: "Provider signed the visit record after the cleaning.",
					where: "Phoenix, AZ"
				},
				oracle: {
					invoiceOk: true,
					deliveryOk: true,
					notes: ["Provider and price matched.", "Signed record accepted."]
				}
			}),
			escrowBase({
				id: "esc-formula",
				needId: "n-formula",
				charityId: "ch-lake",
				amount: 96,
				status: "released",
				createdAt: Date.parse("2026-10-08T15:00:00Z"),
				finishedAt: Date.parse("2026-10-09T17:30:00Z"),
				txFinish: fakeHash("esc-formula:finish"),
				invoice: {
					vendor: "Hearthwell Nutrition",
					lines: "Infant formula, 8 cases",
					total: 96
				},
				proof: {
					kind: "photo",
					note: "Cases photographed in the family-house storeroom.",
					where: "Chicago, IL"
				},
				oracle: {
					invoiceOk: true,
					deliveryOk: true,
					notes: ["Invoice matched.", "Storeroom photo accepted."]
				}
			}),
			escrowBase({
				id: "esc-tabs",
				needId: "n-tabs",
				charityId: "ch-tide",
				amount: 28,
				status: "released",
				createdAt: Date.parse("2026-10-09T15:00:00Z"),
				finishedAt: Date.parse("2026-10-10T14:00:00Z"),
				txFinish: fakeHash("esc-tabs:finish"),
				invoice: {
					vendor: "ClearCurrent Labs",
					lines: "Purification tablets",
					total: 28
				},
				proof: {
					kind: "carrier",
					note: "Carrier scan at the Norfolk warehouse.",
					where: "Norfolk, VA"
				},
				oracle: {
					invoiceOk: true,
					deliveryOk: true,
					notes: ["Invoice matched.", "Carrier scan accepted."]
				}
			}),
			escrowBase({
				id: "esc-blankets",
				needId: "n-blankets",
				charityId: "ch-harbor",
				amount: 144,
				status: "locked",
				createdAt: Date.parse("2026-10-12T15:00:00Z")
			}),
			escrowBase({
				id: "esc-cans",
				needId: "n-cans",
				charityId: "ch-rio",
				amount: 48,
				status: "proof",
				createdAt: Date.parse("2026-10-13T15:00:00Z"),
				invoice: {
					vendor: "Pantry Line Foods",
					lines: "1 case canned protein",
					total: 48
				},
				proof: {
					kind: "carrier",
					note: "Delivered to Rio Mesa Food Bank, dock 2, signed by the pantry lead.",
					where: "Austin, TX"
				}
			})
		]
	};
}
function isFunded(needId, escrows) {
	return escrows.some((escrow) => escrow.needId === needId && escrow.status !== "cancelled");
}
var memoryStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
var storage = createJSONStorage(() => typeof window === "undefined" ? memoryStorage : window.localStorage);
function judge(need, invoice, proof) {
	const invoiceOk = norm(invoice.vendor) === norm(need.vendor) && Math.abs(invoice.total - need.price) < .001;
	const deliveryOk = proof.note.trim().length >= 12 && proof.where.trim().length >= 2;
	const notes = [];
	notes.push(norm(invoice.vendor) === norm(need.vendor) ? "Supplier log: vendor name matches the funded need." : `Supplier log: invoice vendor “${invoice.vendor}” does not match “${need.vendor}”.`);
	notes.push(Math.abs(invoice.total - need.price) < .001 ? "Supplier log: invoice total matches the locked price." : "Supplier log: invoice total does not match the locked price.");
	notes.push(deliveryOk ? "Delivery log: proof note and place are specific enough to accept in this prototype." : "Delivery log: add a specific note (12+ characters) and where it was delivered.");
	return {
		invoiceOk,
		deliveryOk,
		notes
	};
}
var useDemo = create()(persist((set, get) => ({
	...createSeed(),
	fund: (needId, email) => {
		const { needs, charities, escrows } = get();
		const need = needs.find((item) => item.id === needId);
		if (!need) return {
			ok: false,
			reason: "That need is no longer listed."
		};
		if (!charities.find((item) => item.id === need.charityId)?.verified) return {
			ok: false,
			reason: "This charity is not verified yet."
		};
		if (isFunded(needId, escrows)) return {
			ok: false,
			reason: "This item already has an active escrow."
		};
		const receiptEmail = email.trim();
		if (receiptEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(receiptEmail)) return {
			ok: false,
			reason: "Enter a valid email, or leave it blank to give as a guest."
		};
		const id = `esc-${Date.now().toString(36)}`;
		const parts = splitAmount(need.price);
		set({ escrows: [{
			id,
			needId,
			charityId: need.charityId,
			donorTag: "local",
			receiptEmail: receiptEmail || void 0,
			amount: need.price,
			vendorShare: parts.vendor,
			feeShare: parts.fee,
			status: "locked",
			createdAt: Date.now(),
			txCreate: fakeHash(`${id}:create`)
		}, ...escrows] });
		return {
			ok: true,
			id
		};
	},
	addCharity: (input) => {
		const ein = input.ein.trim();
		if (!/^\d{2}-?\d{7}$/.test(ein)) return {
			ok: false,
			reason: "Use an EIN like 12-3456789. The real IRS check happens off-ledger."
		};
		if (input.name.trim().length < 3) return {
			ok: false,
			reason: "Enter the organization’s name."
		};
		if (input.wallet.trim().length < 8) return {
			ok: false,
			reason: "Enter the charity wallet address."
		};
		const formatted = ein.includes("-") ? ein : `${ein.slice(0, 2)}-${ein.slice(2)}`;
		if (get().charities.some((item) => item.ein === formatted)) return {
			ok: false,
			reason: "That EIN is already on the list."
		};
		const id = `ch-${Date.now().toString(36)}`;
		set({ charities: [{
			...input,
			id,
			ein: formatted,
			name: input.name.trim(),
			city: input.city.trim() || "Unlisted",
			state: input.state.trim().toUpperCase().slice(0, 2) || "—",
			wallet: input.wallet.trim(),
			blurb: input.blurb.trim() || "Newly registered in this prototype. Not yet verified.",
			verified: false
		}, ...get().charities] });
		return {
			ok: true,
			id
		};
	},
	verifyCharity: (id) => {
		const charity = get().charities.find((item) => item.id === id);
		if (!charity) return {
			ok: false,
			reason: "Charity not found."
		};
		if (!/^\d{2}-\d{7}$/.test(charity.ein)) return {
			ok: false,
			reason: "EIN format is not valid."
		};
		set({ charities: get().charities.map((item) => item.id === id ? {
			...item,
			verified: true,
			blurb: item.blurb.replace("Not yet verified.", "EIN format accepted in this demo.")
		} : item) });
		return {
			ok: true,
			id
		};
	},
	addNeed: (input) => {
		if (!get().charities.find((item) => item.id === input.charityId)?.verified) return {
			ok: false,
			reason: "Verify the charity before listing a need."
		};
		if (input.title.trim().length < 3) return {
			ok: false,
			reason: "Name the item."
		};
		if (input.vendor.trim().length < 2) return {
			ok: false,
			reason: "Name the vendor who will be paid."
		};
		if (!Number.isFinite(input.price) || input.price <= 0) return {
			ok: false,
			reason: "Enter a price in RLUSD."
		};
		const id = `need-${Date.now().toString(36)}`;
		set({ needs: [{
			...input,
			id,
			title: input.title.trim(),
			detail: input.detail.trim() || "Listed by the charity in this prototype.",
			vendor: input.vendor.trim(),
			vendorWallet: input.vendorWallet.trim() || "rVendorSimulatedVRWn96DkukG4bwd",
			price: Math.round(input.price * 100) / 100
		}, ...get().needs] });
		return {
			ok: true,
			id
		};
	},
	submitProof: (escrowId, invoice, proof) => {
		const escrow = get().escrows.find((item) => item.id === escrowId);
		if (!escrow || escrow.status !== "locked" && escrow.status !== "proof") return {
			ok: false,
			reason: "This escrow is not open for proof."
		};
		if (!invoice.vendor.trim() || !invoice.lines.trim()) return {
			ok: false,
			reason: "The invoice needs a vendor and a line description."
		};
		if (!Number.isFinite(invoice.total)) return {
			ok: false,
			reason: "Enter the invoice total."
		};
		set({ escrows: get().escrows.map((item) => item.id === escrowId ? {
			...item,
			status: "proof",
			invoice: {
				vendor: invoice.vendor.trim(),
				lines: invoice.lines.trim(),
				total: Math.round(invoice.total * 100) / 100
			},
			proof: {
				kind: proof.kind,
				note: proof.note.trim(),
				where: proof.where.trim()
			},
			oracle: void 0
		} : item) });
		return {
			ok: true,
			id: escrowId
		};
	},
	runOracle: (escrowId) => {
		const { escrows, needs } = get();
		const escrow = escrows.find((item) => item.id === escrowId);
		const need = needs.find((item) => item.id === escrow?.needId);
		if (!escrow || !need || escrow.status !== "proof" || !escrow.invoice || !escrow.proof) return {
			ok: false,
			reason: "Submit both proofs before the oracle can run."
		};
		const oracle = judge(need, escrow.invoice, escrow.proof);
		const passed = oracle.invoiceOk && oracle.deliveryOk;
		set({ escrows: escrows.map((item) => item.id === escrowId ? {
			...item,
			oracle,
			status: passed ? "released" : "proof",
			finishedAt: passed ? Date.now() : void 0,
			txFinish: passed ? fakeHash(`${escrowId}:finish`) : void 0
		} : item) });
		return passed ? {
			ok: true,
			id: escrowId
		} : {
			ok: false,
			reason: "The oracle held the escrow. Fix the invoice or the delivery proof."
		};
	},
	cancelEscrow: (escrowId) => {
		const escrow = get().escrows.find((item) => item.id === escrowId);
		if (!escrow || escrow.status === "released" || escrow.status === "cancelled") return {
			ok: false,
			reason: "This escrow can no longer be cancelled."
		};
		set({ escrows: get().escrows.map((item) => item.id === escrowId ? {
			...item,
			status: "cancelled",
			finishedAt: Date.now(),
			txCancel: fakeHash(`${escrowId}:cancel`)
		} : item) });
		return {
			ok: true,
			id: escrowId
		};
	},
	reset: () => set(createSeed())
}), {
	name: "verichar-demo",
	version: 1,
	skipHydration: true,
	storage,
	partialize: (state) => ({
		charities: state.charities,
		needs: state.needs,
		escrows: state.escrows
	})
}));
var LINKS = [
	{
		to: "/give",
		label: "Give"
	},
	{
		to: "/charity",
		label: "Charities"
	},
	{
		to: "/ledger",
		label: "Ledger"
	},
	{
		to: "/enterprise",
		label: "CSR"
	},
	{
		to: "/whitepaper",
		label: "Whitepaper"
	}
];
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className,
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M10 14 L32 54 L54 14",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "9",
			strokeLinejoin: "round",
			strokeLinecap: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M38 18 L46 28 L60 10",
			fill: "none",
			stroke: "currentColor",
			className: "text-green",
			strokeWidth: "6",
			strokeLinejoin: "round",
			strokeLinecap: "round"
		})]
	});
}
function Logo({ inverse = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `inline-flex items-center gap-2 ${inverse ? "text-paper" : "text-ink"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "h-8 w-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-display text-2xl leading-none",
			children: ["VeriChar", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-green",
				children: ".net"
			})]
		})]
	});
}
function Shell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const waiting = useDemo((state) => state.escrows.filter((escrow) => escrow.status === "locked" || escrow.status === "proof").length);
	const reset = useDemo((state) => state.reset);
	(0, import_react.useEffect)(() => {
		useDemo.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							"aria-label": "VeriChar home",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-sm text-muted sm:block",
							children: "Prototype · no real funds"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 pb-3",
						"aria-label": "Primary",
						children: LINKS.map((link) => {
							const on = pathname === link.to;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: link.to,
								className: `inline-flex min-h-11 shrink-0 items-center gap-2 rounded-md px-3 text-sm font-medium ${on ? "bg-ink text-paper" : "text-ink hover:bg-sheet"}`,
								children: [link.label, link.to === "/charity" && waiting > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-sm px-1.5 tabular-nums ${on ? "bg-paper text-ink" : "bg-blue-soft text-blue"}`,
									children: waiting
								}) : null]
							}, link.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-4 pb-3 text-sm text-muted sm:hidden",
						children: "Prototype · no real funds"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mt-16 border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 text-sm text-muted sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium text-ink",
							children: "Brianne Salato, Founder and Product Architect"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1",
							children: "Version 0.5 draft · October 2026. This demo does not process real donations. It is not legal, financial, tax, or investment advice."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: reset,
						className: "min-h-11 text-left font-medium text-blue",
						children: "Reset prototype data"
					})]
				})
			})
		]
	});
}
var STATUS_LABEL = {
	locked: "Funds locked",
	proof: "Proof submitted",
	released: "Vendor paid",
	cancelled: "Returned to donor"
};
var STATUS_CLASS = {
	locked: "bg-blue-soft text-blue",
	proof: "bg-sheet text-ink",
	released: "bg-green-soft text-green",
	cancelled: "bg-red-soft text-red"
};
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex min-h-7 items-center rounded-sm px-2 text-sm font-medium ${STATUS_CLASS[status]}`,
		children: STATUS_LABEL[status]
	});
}
function SectionTitle({ kicker, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "max-w-2xl",
		children: [
			kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-blue",
				children: kicker
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-3xl text-ink sm:text-4xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-0.5 w-10 bg-red",
				"aria-hidden": true
			}),
			children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children
			}) : null
		]
	});
}
function Callout({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "border-l-4 border-red bg-card px-5 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium text-ink",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 text-muted",
			children
		})]
	});
}
var btnPrimary = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-blue px-4 py-2 text-sm font-medium text-paper transition-colors duration-200 hover:bg-ink disabled:cursor-not-allowed disabled:opacity-50";
var btnQuiet = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-line bg-card px-4 py-2 text-sm font-medium text-ink transition-colors duration-200 hover:bg-sheet disabled:cursor-not-allowed disabled:opacity-50";
var btnGreen = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-green px-4 py-2 text-sm font-medium text-paper transition-colors duration-200 hover:bg-ink disabled:cursor-not-allowed disabled:opacity-50";
var btnDanger = "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-red bg-card px-4 py-2 text-sm font-medium text-red transition-colors duration-200 hover:bg-red-soft disabled:cursor-not-allowed disabled:opacity-50";
//#endregion
export { useDemo as _, Shell as a, btnGreen as c, formatWhen as d, isFunded as f, splitAmount as g, shortHash as h, SectionTitle as i, btnPrimary as l, money as m, Callout as n, StatusPill as o, maskEmail as p, PROOF_LABEL as r, btnDanger as s, CAUSES as t, btnQuiet as u };
