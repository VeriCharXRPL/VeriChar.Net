import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useDemo, a as Shell, c as btnGreen, f as isFunded, g as splitAmount, i as SectionTitle, l as btnPrimary, m as money, o as StatusPill, p as maskEmail, t as CAUSES, u as btnQuiet } from "./ui-DZEswU5A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/give-BcAt7-h6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GivePage() {
	const charities = useDemo((state) => state.charities);
	const needs = useDemo((state) => state.needs);
	const escrows = useDemo((state) => state.escrows);
	const fund = useDemo((state) => state.fund);
	const [query, setQuery] = (0, import_react.useState)("");
	const [cause, setCause] = (0, import_react.useState)("All");
	const [stateCode, setStateCode] = (0, import_react.useState)("All");
	const [activeId, setActiveId] = (0, import_react.useState)("n-water");
	const [email, setEmail] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const states = (0, import_react.useMemo)(() => ["All", ...Array.from(new Set(charities.map((charity) => charity.state))).sort()], [charities]);
	const visible = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return charities.filter((charity) => {
			if (!charity.verified) return false;
			if (cause !== "All" && charity.cause !== cause) return false;
			if (stateCode !== "All" && charity.state !== stateCode) return false;
			if (!q) return true;
			return [
				charity.name,
				charity.city,
				charity.state,
				charity.cause,
				charity.ein,
				...needs.filter((need) => need.charityId === charity.id).flatMap((need) => [need.title, need.vendor])
			].join(" ").toLowerCase().includes(q);
		});
	}, [
		charities,
		needs,
		query,
		cause,
		stateCode
	]);
	const active = needs.find((need) => need.id === activeId) ?? null;
	const activeCharity = charities.find((charity) => charity.id === active?.charityId);
	const mine = escrows.filter((escrow) => escrow.donorTag === "local");
	function lockFunds() {
		if (!active) return;
		const result = fund(active.id, email);
		if (!result.ok) {
			setError(result.reason);
			setMessage(null);
			return;
		}
		setError(null);
		setMessage("Escrow created. The charity can now submit an invoice and proof of delivery. You gave as a guest on the ledger.");
		setEmail("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				kicker: "Donors",
				title: "Fund one itemized need.",
				children: "Browse EIN-verified charities. The price is the gift. Optional email for a tax receipt is kept off the ledger."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 grid gap-3 sm:grid-cols-3",
				onSubmit: (event) => event.preventDefault(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Search", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Water, Boston, vendor"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Cause", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "field mt-1",
							value: cause,
							onChange: (event) => setCause(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "All" }), CAUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["State", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field mt-1",
							value: stateCode,
							onChange: (event) => setStateCode(event.target.value),
							children: states.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-8 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "order-2 space-y-6 lg:order-1 lg:col-span-3",
					children: visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-lg border border-line bg-card p-5 text-muted",
						children: "No verified charity matches that search."
					}) : visible.map((charity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-lg border border-line bg-card p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: charity.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-muted",
									children: [
										charity.city,
										", ",
										charity.state,
										" · ",
										charity.cause
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "rounded-sm bg-green-soft px-2 py-1 text-sm font-medium text-green",
									children: ["EIN ", charity.ein]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted",
								children: charity.blurb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 divide-y divide-line",
								children: needs.filter((need) => need.charityId === charity.id).map((need) => {
									const taken = isFunded(need.id, escrows);
									const selected = activeId === need.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										id: need.id,
										className: "flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-medium",
											children: need.title
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: need.vendor
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-3 sm:justify-end",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "tabular-nums font-medium",
												children: money(need.price)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												disabled: taken,
												onClick: () => {
													setActiveId(need.id);
													setMessage(null);
													setError(null);
													document.getElementById("fund-panel")?.scrollIntoView({
														behavior: "smooth",
														block: "start"
													});
												},
												className: taken ? btnQuiet : selected ? btnPrimary : btnQuiet,
												children: taken ? "Funded" : selected ? "Selected" : "Fund this"
											})]
										})]
									}, need.id);
								})
							})
						]
					}, charity.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					id: "fund-panel",
					className: "order-1 scroll-mt-36 lg:order-2 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-line bg-card p-5 lg:sticky lg:top-36",
						children: [
							active && activeCharity && !isFunded(active.id, escrows) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium text-blue",
									children: "Lock this gift"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 font-display text-3xl",
									children: active.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-muted",
									children: [
										activeCharity.name,
										" · ",
										active.vendor
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-display text-4xl tabular-nums",
									children: money(active.price)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "RLUSD, assuming one dollar. The whitepaper treats that peg as still to be confirmed in production."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-4 grid grid-cols-2 gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-md bg-sheet px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Vendor 99%"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "tabular-nums font-medium",
											children: money(splitAmount(active.price).vendor)
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-md bg-sheet px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Fee 1%"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "tabular-nums font-medium",
											children: money(splitAmount(active.price).fee)
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "mt-4 block text-sm font-medium",
									children: ["Email for a tax receipt, optional", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field mt-1",
										type: "email",
										autoComplete: "email",
										value: email,
										placeholder: "Leave blank to stay a guest",
										onChange: (event) => setEmail(event.target.value)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: "If you add an email, this prototype keeps it in the browser only. It is never written on the public ledger."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: `${btnGreen} mt-4 w-full`,
									onClick: lockFunds,
									children: "Lock funds in escrow"
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-blue",
								children: "Choose an open item"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-muted",
								children: "Funded items stay locked until proof clears or the escrow is cancelled and the gift returns to the donor."
							})] }),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-red",
								children: error
							}) : null,
							message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-green",
								children: message
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-4 rounded-lg border border-line bg-card p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-medium",
							children: "Your gifts in this browser"
						}), mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "None yet. The water case at Harbor Light is the whitepaper’s example."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 space-y-3",
							children: mine.map((escrow) => {
								const need = needs.find((item) => item.id === escrow.needId);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start justify-between gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: need?.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-muted",
										children: escrow.receiptEmail ? `Receipt ${maskEmail(escrow.receiptEmail)}` : "Guest · no receipt email"
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: escrow.status })]
								}, escrow.id);
							})
						})]
					})]
				})]
			})
		]
	}) });
}
//#endregion
export { GivePage as component };
