import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useDemo, a as Shell, c as btnGreen, i as SectionTitle, l as btnPrimary, m as money, o as StatusPill, r as PROOF_LABEL, s as btnDanger, t as CAUSES, u as btnQuiet } from "./ui-DZEswU5A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/charity-pDtdJ-gA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CharityPage() {
	const charities = useDemo((state) => state.charities);
	const needs = useDemo((state) => state.needs);
	const escrows = useDemo((state) => state.escrows);
	const addCharity = useDemo((state) => state.addCharity);
	const verifyCharity = useDemo((state) => state.verifyCharity);
	const addNeed = useDemo((state) => state.addNeed);
	const verified = charities.filter((charity) => charity.verified);
	const [charityId, setCharityId] = (0, import_react.useState)("ch-harbor");
	const [mode, setMode] = (0, import_react.useState)("portal");
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [problem, setProblem] = (0, import_react.useState)(null);
	const [org, setOrg] = (0, import_react.useState)({
		name: "",
		ein: "",
		city: "",
		state: "",
		cause: "Shelter",
		wallet: "",
		blurb: ""
	});
	const [draftNeed, setDraftNeed] = (0, import_react.useState)({
		title: "",
		price: "",
		vendor: "",
		detail: ""
	});
	const selected = charities.find((charity) => charity.id === charityId) ?? verified[0];
	const queue = escrows.filter((escrow) => escrow.charityId === selected?.id && (escrow.status === "locked" || escrow.status === "proof"));
	function flash(result, okText) {
		if (!result.ok) {
			setProblem(result.reason ?? "Something blocked that step.");
			setNotice(null);
			return;
		}
		setProblem(null);
		setNotice(okText);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				kicker: "Charities",
				title: "List the need. Prove the delivery. Never hold the cash.",
				children: "Registration checks the EIN format and binds a wallet. In production the IRS lookup and any XRPL credential happen outside this demo."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: mode === "portal" ? btnPrimary : btnQuiet,
					onClick: () => setMode("portal"),
					children: "Act as a charity"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: mode === "register" ? btnPrimary : btnQuiet,
					onClick: () => setMode("register"),
					children: "Register"
				})]
			}),
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-green",
				children: notice
			}) : null,
			problem ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-red",
				children: problem
			}) : null,
			mode === "register" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 grid max-w-2xl gap-3 rounded-lg border border-line bg-card p-5",
				onSubmit: (event) => {
					event.preventDefault();
					const result = addCharity({
						...org,
						wallet: org.wallet || "rNewCharitySimulatedVRWn96Dkuk"
					});
					flash(result, "Registered. Run the EIN check before this organization can list needs.");
					if (result.ok) setCharityId(result.id);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["Organization", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: org.name,
							onChange: (event) => setOrg({
								...org,
								name: event.target.value
							}),
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["EIN", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								value: org.ein,
								placeholder: "12-3456789",
								onChange: (event) => setOrg({
									...org,
									ein: event.target.value
								}),
								required: true
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["Cause", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field mt-1",
								value: org.cause,
								onChange: (event) => setOrg({
									...org,
									cause: event.target.value
								}),
								children: CAUSES.map((cause) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: cause }, cause))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								value: org.city,
								onChange: (event) => setOrg({
									...org,
									city: event.target.value
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["State", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "field mt-1",
								maxLength: 2,
								value: org.state,
								placeholder: "MA",
								onChange: (event) => setOrg({
									...org,
									state: event.target.value
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["Wallet address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: org.wallet,
							placeholder: "r…",
							onChange: (event) => setOrg({
								...org,
								wallet: event.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["What you do", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field mt-1",
							value: org.blurb,
							onChange: (event) => setOrg({
								...org,
								blurb: event.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: btnPrimary,
						children: "Register organization"
					})
				]
			}) : null,
			mode === "portal" && selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm font-medium",
							children: ["Acting as", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "field mt-1",
								value: selected.id,
								onChange: (event) => {
									setCharityId(event.target.value);
									setNotice(null);
									setProblem(null);
								},
								children: verified.map((charity) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: charity.id,
									children: charity.name
								}, charity.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [
								selected.city,
								", ",
								selected.state,
								" · EIN ",
								selected.ein
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-6 font-display text-2xl",
							children: "Open needs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 divide-y divide-line",
							children: needs.filter((need) => need.charityId === selected.id).map((need) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 py-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: need.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: money(need.price)
								})]
							}, need.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "mt-4 grid gap-3",
							onSubmit: (event) => {
								event.preventDefault();
								const result = addNeed({
									charityId: selected.id,
									title: draftNeed.title,
									detail: draftNeed.detail,
									price: Number(draftNeed.price),
									vendor: draftNeed.vendor,
									vendorWallet: "rVendorSimulatedVRWn96DkukG4bwd"
								});
								flash(result, "Need listed. A donor can fund it from the catalog.");
								if (result.ok) setDraftNeed({
									title: "",
									price: "",
									vendor: "",
									detail: ""
								});
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-medium",
									children: "List another need"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									placeholder: "Item",
									value: draftNeed.title,
									onChange: (event) => setDraftNeed({
										...draftNeed,
										title: event.target.value
									}),
									required: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-3 sm:grid-cols-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field",
										placeholder: "Price in RLUSD",
										inputMode: "decimal",
										value: draftNeed.price,
										onChange: (event) => setDraftNeed({
											...draftNeed,
											price: event.target.value
										}),
										required: true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										className: "field",
										placeholder: "Vendor to be paid",
										value: draftNeed.vendor,
										onChange: (event) => setDraftNeed({
											...draftNeed,
											vendor: event.target.value
										}),
										required: true
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									placeholder: "Short detail",
									value: draftNeed.detail,
									onChange: (event) => setDraftNeed({
										...draftNeed,
										detail: event.target.value
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "submit",
									className: btnQuiet,
									children: "List need"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: "Gifts under $20 may be uneconomic once real escrow fees are measured. This demo does not charge them."
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: "Proof queue"
						}),
						queue.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-lg border border-line bg-card p-5 text-sm text-muted",
							children: "Nothing is waiting. When a donor locks a need, it appears here for the invoice and the delivery proof."
						}) : queue.map((escrow) => {
							const need = needs.find((item) => item.id === escrow.needId);
							if (!need) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProofCard, {
								escrowId: escrow.id,
								title: need.title,
								vendor: need.vendor,
								price: need.price,
								city: selected.city,
								stateCode: selected.state,
								status: escrow.status,
								oracleNotes: escrow.oracle?.notes,
								onDone: (result, okText) => flash(result, okText)
							}, escrow.id);
						}),
						charities.some((charity) => !charity.verified) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-line bg-card p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: "Waiting on the EIN check"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 space-y-3",
								children: charities.filter((charity) => !charity.verified).map((charity) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex flex-wrap items-center justify-between gap-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										charity.name,
										" · ",
										charity.ein
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: btnQuiet,
										onClick: () => flash(verifyCharity(charity.id), `${charity.name} is verified in this demo. A production check would use IRS records, off-ledger.`),
										children: "Run EIN check"
									})]
								}, charity.id))
							})]
						}) : null
					]
				})]
			}) : null
		]
	}) });
}
function ProofCard({ escrowId, title, vendor, price, city, stateCode, status, oracleNotes, onDone }) {
	const submitProof = useDemo((state) => state.submitProof);
	const runOracle = useDemo((state) => state.runOracle);
	const cancelEscrow = useDemo((state) => state.cancelEscrow);
	const [kind, setKind] = (0, import_react.useState)("photo");
	const [vendorName, setVendorName] = (0, import_react.useState)(vendor);
	const [lines, setLines] = (0, import_react.useState)(title);
	const [total, setTotal] = (0, import_react.useState)(String(price));
	const [note, setNote] = (0, import_react.useState)("");
	const [where, setWhere] = (0, import_react.useState)("");
	function send(invoiceVendor, invoiceLines, invoiceTotal, proofNote, proofWhere, okText) {
		const result = submitProof(escrowId, {
			vendor: invoiceVendor,
			lines: invoiceLines,
			total: invoiceTotal
		}, {
			kind,
			note: proofNote,
			where: proofWhere
		});
		if (result.ok) {
			setVendorName(invoiceVendor);
			setLines(invoiceLines);
			setTotal(String(invoiceTotal));
			setNote(proofNote);
			setWhere(proofWhere);
		}
		onDone(result, okText);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-lg border border-line bg-card p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-2xl",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						vendor,
						" · ",
						money(price),
						" RLUSD"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["Invoice vendor", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: vendorName,
							onChange: (event) => setVendorName(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["Line items", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: lines,
							onChange: (event) => setLines(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["Invoice total", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							inputMode: "decimal",
							value: total,
							onChange: (event) => setTotal(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["Proof of delivery", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "field mt-1",
							value: kind,
							onChange: (event) => setKind(event.target.value),
							children: Object.keys(PROOF_LABEL).map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: key,
								children: PROOF_LABEL[key]
							}, key))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["What was observed", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "field mt-1",
							value: note,
							onChange: (event) => setNote(event.target.value),
							placeholder: "At least 12 characters. Say what arrived and that it matched."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-sm font-medium",
						children: ["Where", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field mt-1",
							value: where,
							onChange: (event) => setWhere(event.target.value),
							placeholder: "City, ST"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btnQuiet,
						onClick: () => send(vendor, title, price, `Delivered to ${city}. Count matched the funded item and the seal was intact.`, `${city}, ${stateCode}`, "Matching proofs submitted. Run the oracle."),
						children: "Submit a matching pair"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btnQuiet,
						onClick: () => send(`${vendor} Holdings`, title, Math.round(price * 140) / 100, "Photo of a different shipment. The count was not checked.", `${city}, ${stateCode}`, "Inflated invoice submitted. Run the oracle to see it held."),
						children: "Submit an inflated invoice"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: btnPrimary,
							onClick: () => send(vendorName, lines, Number(total), note, where, "Your invoice and proof were submitted. Run the oracle."),
							children: "Submit what I typed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: btnGreen,
							disabled: status !== "proof",
							onClick: () => onDone(runOracle(escrowId), "Both proofs passed. Escrow finished and the vendor is paid."),
							children: "Run oracle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: btnDanger,
							onClick: () => onDone(cancelEscrow(escrowId), "Escrow cancelled. After expiry, the design returns the funds to the sender."),
							children: "Cancel escrow"
						})
					]
				})]
			}),
			oracleNotes && oracleNotes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 space-y-1 text-sm text-muted",
				children: oracleNotes.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: line }, line))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: "The oracle checks vendor, price, and a specific delivery note. Both logs must pass."
			})
		]
	});
}
//#endregion
export { CharityPage as component };
