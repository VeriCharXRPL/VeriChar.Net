import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shell, g as splitAmount, i as SectionTitle, m as money, n as Callout, u as btnQuiet } from "./ui-DZEswU5A.mjs";
import { a as Lock, i as ScanSearch, o as ArrowRight, r as ShieldCheck, t as Truck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D91PcEEu.js
var import_jsx_runtime = require_jsx_runtime();
var STEPS = [
	{
		n: "1",
		title: "Donor funds a specific need",
		body: "Not a pooled general fund. One item, one price, one named vendor."
	},
	{
		n: "2",
		title: "Escrow locks funds on the XRPL",
		body: "A conditional escrow names the vendor up front. The charity never holds the cash."
	},
	{
		n: "3",
		title: "Charity submits invoice and proof",
		body: "An itemized merchant invoice, plus a photo, a carrier scan, or a signed receipt."
	},
	{
		n: "4",
		title: "Oracle verifies both proofs",
		body: "Supplier log and delivery log must both pass. The fulfillment stays guarded until then."
	},
	{
		n: "5",
		title: "Vendor paid directly",
		body: "Finishing the escrow delivers 99% to the vendor and 1% to VeriChar."
	}
];
var PROBLEMS = [
	{
		title: "Opacity",
		body: "Donations are usually pooled. A donor cannot trace a specific dollar to a specific purchase."
	},
	{
		title: "Diversion and fraud",
		body: "When money moves first and reports follow later, problems surface only after the damage is done."
	},
	{
		title: "The burden of proof",
		body: "Honest charities assemble receipts after the fact. The process is slow and hard for an outsider to audit."
	},
	{
		title: "Privacy versus transparency",
		body: "Many donors want to give without being tracked, and still want proof the gift was used properly."
	}
];
function Home() {
	const water = splitAmount(20);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-ink text-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 sm:py-20 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium tracking-widest text-paper/70",
						children: "WHITEPAPER · VERSION 0.5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-5xl leading-tight sm:text-6xl",
						children: "Verifiable charity on the XRP Ledger"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-0.5 w-10 bg-red",
						"aria-hidden": true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-lg text-paper/80",
						children: "Proof comes before payment. Every gift funds one itemized need in RLUSD, stays locked in escrow, and reaches the vendor only when both proofs verify."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/give",
							className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-paper px-4 py-2 text-sm font-medium text-ink hover:bg-sheet",
							children: ["Fund a specific need", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/charity",
							className: "inline-flex min-h-11 items-center justify-center rounded-md border border-paper/30 px-4 py-2 text-sm font-medium text-paper hover:bg-ink-soft",
							children: "Act as a charity"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-paper/15 bg-ink-soft p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-paper/70",
							children: "Example gift · not a live transaction"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-3xl",
							children: "4 cases of water"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-paper/80",
							children: "Harbor Light Shelter · Boston · Northline Wholesale"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 font-display text-4xl tabular-nums",
							children: [
								money(20),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-lg",
									children: "RLUSD"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-4 grid grid-cols-2 gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md bg-ink px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-paper/70",
									children: "Vendor, 99%"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-lg font-medium tabular-nums",
									children: money(water.vendor)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-md bg-ink px-3 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-paper/70",
									children: "VeriChar, 1%"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-lg font-medium tabular-nums",
									children: money(water.fee)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "h-4 w-4 text-paper/70" }), " Escrow created with an expiry"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScanSearch, { className: "h-4 w-4 text-paper/70" }), " Invoice matched the funded need"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { className: "h-4 w-4 text-green" }), " Delivery proof accepted"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4 text-green" }), " Vendor paid. Shelter never held the cash."]
								})
							]
						})
					]
				})
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl space-y-16 px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
				title: "Document status",
				children: "This is a working interactive prototype of the Version 0.5 design. It will be tested on the XRP Ledger test network, and reviewed by legal and security professionals, before any real funds are handled. Nothing here moves RLUSD or XRP."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				kicker: "The problem",
				title: "Giving still asks you to take someone at their word.",
				children: "Four structural gaps follow from paying first and reporting later."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-4 sm:grid-cols-2",
				children: PROBLEMS.map((problem) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-card p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl",
						children: problem.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: problem.body
					})]
				}, problem.title))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				kicker: "The approach",
				title: "Lock the funds first. Release them when the evidence exists."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 grid gap-4 lg:grid-cols-5",
				children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-lg border border-line bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `inline-flex h-8 w-8 items-center justify-center rounded-sm text-sm font-medium ${step.n === "5" ? "bg-green text-paper" : "bg-ink text-paper"}`,
							children: step.n
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 font-medium",
							children: step.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: step.body
						})
					]
				}, step.n))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				kicker: "Try the prototype",
				title: "Walk a gift from lock to release.",
				children: "The same browser keeps the escrow. Fund an item, submit proof as the charity, then read it on the public ledger."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/give",
						className: "rounded-lg border border-line bg-card p-5 hover:border-blue",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-blue",
								children: "Donor"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-display text-2xl",
								children: "Fund one item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Search by cause, state, or keyword. Give as a guest. A tax-receipt email stays off the ledger."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-4 ${btnQuiet}`,
								children: "Open the catalog"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/charity",
						className: "rounded-lg border border-line bg-card p-5 hover:border-blue",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-blue",
								children: "Charity"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-display text-2xl",
								children: "Submit both proofs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Blankets are already locked. Canned protein is waiting on the oracle. Or register a new EIN."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-4 ${btnQuiet}`,
								children: "Open the portal"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/enterprise",
						className: "rounded-lg border border-line bg-card p-5 hover:border-blue",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-blue",
								children: "Enterprise"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-2 font-display text-2xl",
								children: "Read the CSR record"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "What gets licensed is the verification and the report. The raw ledger is already public."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-4 ${btnQuiet}`,
								children: "Open the dashboard"
							})
						]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-8 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					kicker: "Two proofs",
					title: "The rule does not change with the item.",
					children: "A pallet can be proved with a carrier confirmation. A dental visit can be proved with a signed provider record. Funds release only after the proof is verified."
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-lg bg-blue-soft p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium text-blue",
							children: "Supplier log"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-ink",
							children: "The invoice is read for vendor, line items, and price, then compared with the funded need."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-lg bg-green-soft p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium text-green",
							children: "Delivery log"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-ink",
							children: "A photo is checked for time, place, and a tamper-evident record. Shipped goods can use a carrier confirmation instead."
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					kicker: "Honest limit",
					title: "A true record is not the same as an honest event."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-muted",
					children: "Cryptographic proof shows that a record is authentic and unaltered. It cannot prove the underlying event was honest. VeriChar narrows the chance to divert funds and makes fraud easier to see. It does not make fraud impossible."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/whitepaper",
						className: btnQuiet,
						children: ["Read the draft whitepaper", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
					})
				})
			] })
		]
	})] });
}
//#endregion
export { Home as component };
