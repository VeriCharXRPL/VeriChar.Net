import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Shell, n as Callout } from "./ui-DZEswU5A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/whitepaper-y8D2naTr.js
var import_jsx_runtime = require_jsx_runtime();
var TOC = [
	["summary", "Executive summary"],
	["problem", "The problem"],
	["approach", "The approach"],
	["architecture", "System architecture"],
	["proof", "Cryptographic proof"],
	["experience", "Donor and charity experience"],
	["modules", "Planned modules"],
	["model", "Business model"],
	["risk", "Security and risk"],
	["compliance", "Compliance"],
	["roadmap", "Roadmap"],
	["close", "Conclusion"]
];
function PaperPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium tracking-widest text-blue",
				children: "WHITEPAPER · VERSION 0.5 DRAFT"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl leading-tight",
				children: "Verifiable charity on the XRP Ledger"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-0.5 w-10 bg-red",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-lg text-muted",
				children: "Proof comes before payment. Brianne Salato, Founder and Product Architect. October 2026."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Callout, {
					title: "How to read this draft",
					children: "The system described here is the intended design. Statements about the XRP Ledger were checked against XRPL.org and Ripple RLUSD documentation. Details marked “to be confirmed” are not yet verified against the specification. This page is a reading copy of that draft, inside the interactive prototype."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-8",
				"aria-label": "Contents",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "grid gap-2 sm:grid-cols-2",
					children: TOC.map(([id, label], index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "text-blue",
						href: `#${id}`,
						children: [
							index + 1,
							". ",
							label
						]
					}) }, id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "summary",
				title: "1. Executive summary",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Charitable giving runs on trust, and trust is hard to verify. Donors rarely see what their gift actually bought. Charities carry the burden of proving impact after the money is already spent." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "VeriChar is a verification layer on the XRP Ledger. Every donation funds one specific, itemized need and is paid in RLUSD. The funds are locked in escrow and released directly to the vendor only when an itemized merchant invoice and cryptographic proof of delivery both verify. The charity never holds the cash. Every step is written to a public ledger." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "VeriChar is free for donors and charities. It is sustained by a 1% vendor settlement fee and by licensing audit-ready CSR data. Both are designed to be collected on the XRP Ledger." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "problem",
				title: "2. The problem",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Opacity: donations are pooled, so a donor cannot trace a specific dollar to a specific purchase." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Diversion and fraud: unverified organizations, misused funds, and inflated costs are hard to detect when money moves first." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The burden of proof: honest charities must assemble reports by hand." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Privacy versus transparency: donors often want both anonymity and proof. Existing platforms usually force a choice." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "approach",
				title: "3. The VeriChar approach",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The order of events changes. Funds are locked first and released only when the evidence exists: donor funds a need, escrow locks on the XRPL, the charity submits invoice and proof, an oracle verifies both, and the vendor is paid directly." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Charities are checked against an EIN in IRS records, off-ledger, and the wallet is bound to that identity. The XRPL can also link an account to a domain, and Credentials are a possible fit still to be confirmed." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "An escrow names its recipient, here the vendor, when it is created. Finishing it delivers the funds to that recipient. The charity never touches the money." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "architecture",
				title: "4. System architecture",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Four layers, each with one job." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-ink",
						children: "Ledger."
					}), " Native XRPL escrow, not custom smart-contract code. VeriChar uses a conditional escrow: the only crypto-condition type the ledger supports is PREIMAGE-SHA-256. A conditional escrow with no finish-after time must have an expiry. Every VeriChar escrow carries one, or a failed delivery could lock funds permanently. The oracle must guard the fulfillment, because whoever holds it can release the funds."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-ink",
						children: "RLUSD."
					}), " A USD stablecoin issued as a native token. Trust-line tokens can be escrowed only if the issuer enables Allow Trust Line Locking, and token escrows must always expire. Whether RLUSD itself can be escrowed was not confirmed in the sources reviewed. That is a blocking test before the fee flow can be built on RLUSD."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-ink",
						children: "Oracle."
					}), " Two checks, both required. The supplier log compares the invoice with the funded need. The delivery log inspects photo metadata, a timestamp, and GPS, or accepts a carrier confirmation. This is not the XRPL’s on-ledger price oracle."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-ink",
						children: "Privacy."
					}), " Guests need no VeriChar account, but an XRPL address is still required to send funds. How guest wallets are created and funded is an open design question. A tax-receipt email is encrypted off-chain. A “Stealth Escrow” that weakens the visible link between donor and gift is planned, not built."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "font-medium text-ink",
						children: "Application."
					}), " A donor catalog, a charity portal, and an enterprise CSR dashboard. You are using those three now."] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "proof",
				title: "5. Cryptographic proof, explained",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A hash is a digital fingerprint: change any detail and the code changes. A signature shows who confirmed a record. A public ledger lets anyone look a validated transaction up by its hash, and recorded data cannot be altered unless a majority of validators agree." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Which VeriChar proof data is written on-ledger, and whether delivery records are signed with ripple-keypairs, is still to be confirmed. The rule is already fixed: funds release only after the proof is verified." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "experience",
				title: "6. Donor and charity experience",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Donors browse verified charities, fund one item, give as a guest, and watch the status move from funds locked, to proof submitted, to released." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Charities register with a name, wallet, and EIN, list needs with a price and vendor, and submit the invoice and proof when goods arrive. They pay nothing." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "modules",
				title: "7. Planned modules",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-ink",
					children: "Subscription escrows."
				}), " For baseline goods, a donor can lock a pool. Every 30 days the vault creates a new itemized escrow from updated inventory. Each release still requires both proofs. The sender covers the reserve on every incomplete escrow, so the monthly cycle has to budget for that."] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "font-medium text-ink",
					children: "From Dust to Dreams."
				}), " Small leftover balances can be swept into a cause vault and deployed only when a full item is funded. Pooling is meant to spread escrow costs that the documentation warns can make tiny gifts infeasible. Whether it is economical has to be tested."] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "model",
				title: "8. Business model",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Free for donors and charities. The vendor fee is two conditional escrows, because an escrow has one named recipient: 99% to the vendor and 1% to VeriChar. Both finish only after both proofs pass. If proof never arrives, both expire and the funds return to the sender. A $20 item splits into 19.80 and 0.20." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "An issuer transfer fee is not VeriChar revenue. RLUSD’s issuer is Ripple. If a transfer fee existed it would reduce what recipients receive. The settings reviewed do not list one." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "CSR customers pay the revenue account in RLUSD. A destination tag is the usual way to tell payments apart. VeriChar would credit a subscription only after a validated tesSUCCESS and delivered_amount. Because the raw records are public, the license is the verification and the reporting built on them." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Revenue is in RLUSD and fees and reserves are in XRP, so the operator must hold an XRP float. Margins cannot be computed from the documentation alone." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "risk",
				title: "9. Security and risk",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Forged invoices are met with parsing, price checks, duplicate detection, a vendor registry, and human review of exceptions. Spoofed photos are met with metadata checks, signed capture, and random audits. Charity-vendor collusion is met with benchmarking and a way to report concerns." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Oracle compromise is met by guarding fulfillment secrets like keys, with a roadmap toward multiple independent oracles. Lost keys are met by keeping the master key offline, rotating a regular key, and multi-signing high-value accounts. Misread payments are met by counting only validated tesSUCCESS results and delivered_amount, not the Amount field." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Every escrow gets a CancelAfter. Without it, an escrow never expires and cannot be cancelled. Costs on small gifts will be measured on testnet before minimum sizes are set. Production would run its own xrpld and Clio servers, because a malicious server can misreport payments." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "RLUSD removes most price swing on the gift itself. The issuer can claw back or freeze the token. Whether clawback reaches escrowed RLUSD is not covered by the sources reviewed." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				id: "compliance",
				title: "10. Compliance considerations",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Qualified counsel has to review this before any live launch. Areas called out in the draft: money transmission, charitable solicitation, AML screening, tax treatment of digital assets, data protection, and token or securities rules. Escrow is designed to avoid VeriChar taking custody. That has to be confirmed, not assumed. Charities, not VeriChar, would issue tax receipts." })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				id: "roadmap",
				title: "11. Roadmap",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Phase 0, this prototype of the donor flow, charity onboarding, oracle, and release, is the working demo. Phase 1 tests RLUSD conditional escrow with an expiry on the test network, including whether RLUSD can be escrowed at all. Phase 2 is a small pilot after legal and security review. Phase 3 adds subscription escrows, dust pools, multiple oracles, and the enterprise dashboard in production form." })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				id: "close",
				title: "12. Conclusion",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Generosity should not require surrendering your common sense. Donors see what the gift bought. Honest charities gain a credible way to prove the work. Vendors are paid promptly. The record belongs to everyone." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Trust should be enforced by code, not demanded by slogans." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-12 border-t border-line pt-6 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "About the author: Brianne Salato. VeriChar@proton.me · @VeriCharOnChain · verichar.net" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3",
					children: "This document is for information only and is not legal, financial, tax, or investment advice. It describes planned functionality. VeriChar does not currently process real donations. Nothing here is an offer to sell or a solicitation to buy any asset or security."
				})]
			})
		]
	}) });
}
function Section({ id, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id,
		className: "mt-10 scroll-mt-36",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 h-0.5 w-10 bg-red",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 space-y-3 text-muted",
				children
			})
		]
	});
}
//#endregion
export { PaperPage as component };
