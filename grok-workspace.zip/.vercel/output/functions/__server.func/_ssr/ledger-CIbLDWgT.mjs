import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as useDemo, a as Shell, d as formatWhen, h as shortHash, i as SectionTitle, m as money, o as StatusPill } from "./ui-DZEswU5A.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ledger-CIbLDWgT.js
var import_jsx_runtime = require_jsx_runtime();
var STATUS_COPY = {
	locked: "Funds are locked. Only the fulfillment, which the oracle holds, can finish this escrow.",
	proof: "Both documents are in, or a check failed and the escrow is still open.",
	released: "EscrowFinish delivered the vendor share to the named vendor and the 1% fee to VeriChar.",
	cancelled: "The expiry path returned the full amount to the sender. The vendor was not paid."
};
function LedgerPage() {
	const escrows = useDemo((state) => state.escrows);
	const needs = useDemo((state) => state.needs);
	const charities = useDemo((state) => state.charities);
	const ordered = [...escrows].sort((a, b) => b.createdAt - a.createdAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
			kicker: "Public record",
			title: "Anyone can read the escrow. Not the donor’s email.",
			children: "Hashes here are simulated so the prototype can show the audit shape. A production record would be a validated XRPL transaction with result tesSUCCESS."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 overflow-hidden rounded-lg border border-line bg-card",
			children: ordered.map((escrow) => {
				const need = needs.find((item) => item.id === escrow.needId);
				const charity = charities.find((item) => item.id === escrow.charityId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
					className: "border-b border-line last:border-b-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
						className: "flex flex-col gap-2 px-4 py-4 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: need?.title ?? "Need removed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted",
							children: [
								charity?.name ?? "Charity",
								" · ",
								formatWhen(escrow.createdAt),
								" · ",
								shortHash(escrow.txCreate)
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: money(escrow.amount)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: escrow.status })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 px-4 pb-5 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted",
								children: STATUS_COPY[escrow.status]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "grid grid-cols-2 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "Vendor"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums font-medium",
										children: money(escrow.vendorShare)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-muted",
										children: "VeriChar 1%"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "tabular-nums font-medium",
										children: money(escrow.feeShare)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Create hash"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "break-all font-mono text-xs",
											children: escrow.txCreate
										})]
									}),
									escrow.txFinish ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Finish hash"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "break-all font-mono text-xs",
											children: escrow.txFinish
										})]
									}) : null,
									escrow.txCancel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "text-muted",
											children: "Cancel hash"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "break-all font-mono text-xs",
											children: escrow.txCancel
										})]
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-muted sm:col-span-2",
								children: "Condition type on the real ledger would be PREIMAGE-SHA-256. The fulfillment is treated like a key: whoever holds it can finish the escrow, so the oracle must guard it. Every VeriChar escrow needs an expiry, or a failed delivery could lock funds permanently."
							}),
							escrow.invoice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "sm:col-span-2",
								children: [
									"Invoice on file: ",
									escrow.invoice.vendor,
									" · ",
									escrow.invoice.lines,
									" · ",
									money(escrow.invoice.total)
								]
							}) : null
						]
					})]
				}, escrow.id);
			})
		})]
	}) });
}
//#endregion
export { LedgerPage as component };
