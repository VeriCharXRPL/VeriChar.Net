//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BYcdRJHJ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/charity",
			"/enterprise",
			"/give",
			"/ledger",
			"/whitepaper"
		],
		preloads: ["/assets/index-smspek9H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-smspek9H.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DU9tK8wp.js", "/assets/ui-mK421dRN.js"]
	},
	"/charity": {
		filePath: "/workspace/src/routes/charity.tsx",
		children: void 0,
		preloads: ["/assets/charity-CboJ4N5p.js", "/assets/ui-mK421dRN.js"]
	},
	"/enterprise": {
		filePath: "/workspace/src/routes/enterprise.tsx",
		children: void 0,
		preloads: ["/assets/enterprise-BUEV6uDJ.js", "/assets/ui-mK421dRN.js"]
	},
	"/give": {
		filePath: "/workspace/src/routes/give.tsx",
		children: void 0,
		preloads: ["/assets/give-D3NDKjAH.js", "/assets/ui-mK421dRN.js"]
	},
	"/ledger": {
		filePath: "/workspace/src/routes/ledger.tsx",
		children: void 0,
		preloads: ["/assets/ledger-CI848de4.js", "/assets/ui-mK421dRN.js"]
	},
	"/whitepaper": {
		filePath: "/workspace/src/routes/whitepaper.tsx",
		children: void 0,
		preloads: ["/assets/whitepaper-X3z680Ci.js", "/assets/ui-mK421dRN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
