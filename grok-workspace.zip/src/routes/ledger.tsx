import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { SectionTitle, StatusPill } from "@/components/ui";
import { formatWhen, money, shortHash } from "@/lib/demo";
import { useDemo } from "@/lib/store";

export const Route = createFileRoute("/ledger")({
  component: LedgerPage,
  head: () => ({ meta: [{ title: "Ledger · VeriChar" }] }),
});

const STATUS_COPY = {
  locked: "Funds are locked. Only the fulfillment, which the oracle holds, can finish this escrow.",
  proof: "Both documents are in, or a check failed and the escrow is still open.",
  released: "EscrowFinish delivered the vendor share to the named vendor and the 1% fee to VeriChar.",
  cancelled: "The expiry path returned the full amount to the sender. The vendor was not paid.",
} as const;

function LedgerPage() {
  const escrows = useDemo((state) => state.escrows);
  const needs = useDemo((state) => state.needs);
  const charities = useDemo((state) => state.charities);
  const ordered = [...escrows].sort((a, b) => b.createdAt - a.createdAt);

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <SectionTitle kicker="Public record" title="Anyone can read the escrow. Not the donor’s email.">
          Hashes here are simulated so the prototype can show the audit shape. A production record would be a validated XRPL transaction with result tesSUCCESS.
        </SectionTitle>

        <div className="mt-8 overflow-hidden rounded-lg border border-line bg-card">
          {ordered.map((escrow) => {
            const need = needs.find((item) => item.id === escrow.needId);
            const charity = charities.find((item) => item.id === escrow.charityId);
            return (
              <details key={escrow.id} className="border-b border-line last:border-b-0">
                <summary className="flex flex-col gap-2 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                  <span>
                    <span className="block font-medium">{need?.title ?? "Need removed"}</span>
                    <span className="text-sm text-muted">
                      {charity?.name ?? "Charity"} · {formatWhen(escrow.createdAt)} · {shortHash(escrow.txCreate)}
                    </span>
                  </span>
                  <span className="flex items-center gap-3">
                    <span className="tabular-nums">{money(escrow.amount)}</span>
                    <StatusPill status={escrow.status} />
                  </span>
                </summary>
                <div className="grid gap-4 px-4 pb-5 text-sm sm:grid-cols-2">
                  <p className="text-muted">{STATUS_COPY[escrow.status]}</p>
                  <dl className="grid grid-cols-2 gap-2">
                    <div>
                      <dt className="text-muted">Vendor</dt>
                      <dd className="tabular-nums font-medium">{money(escrow.vendorShare)}</dd>
                    </div>
                    <div>
                      <dt className="text-muted">VeriChar 1%</dt>
                      <dd className="tabular-nums font-medium">{money(escrow.feeShare)}</dd>
                    </div>
                    <div className="col-span-2">
                      <dt className="text-muted">Create hash</dt>
                      <dd className="break-all font-mono text-xs">{escrow.txCreate}</dd>
                    </div>
                    {escrow.txFinish ? (
                      <div className="col-span-2">
                        <dt className="text-muted">Finish hash</dt>
                        <dd className="break-all font-mono text-xs">{escrow.txFinish}</dd>
                      </div>
                    ) : null}
                    {escrow.txCancel ? (
                      <div className="col-span-2">
                        <dt className="text-muted">Cancel hash</dt>
                        <dd className="break-all font-mono text-xs">{escrow.txCancel}</dd>
                      </div>
                    ) : null}
                  </dl>
                  <p className="text-muted sm:col-span-2">
                    Condition type on the real ledger would be PREIMAGE-SHA-256. The fulfillment is treated like a key: whoever holds it can finish the escrow, so the oracle must guard it. Every VeriChar escrow needs an expiry, or a failed delivery could lock funds permanently.
                  </p>
                  {escrow.invoice ? (
                    <p className="sm:col-span-2">
                      Invoice on file: {escrow.invoice.vendor} · {escrow.invoice.lines} · {money(escrow.invoice.total)}
                    </p>
                  ) : null}
                </div>
              </details>
            );
          })}
        </div>
      </div>
    </Shell>
  );
}
