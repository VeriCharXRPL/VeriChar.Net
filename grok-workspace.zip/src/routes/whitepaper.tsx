import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { Callout } from "@/components/ui";

export const Route = createFileRoute("/whitepaper")({
  component: PaperPage,
  head: () => ({ meta: [{ title: "Whitepaper · VeriChar" }] }),
});

const TOC = [
  ["summary", "Executive summary"],
  ["problem", "The problem"],
  ["approach", "The approach"],
  ["architecture", "System architecture"],
  ["proof", "Cryptographic proof"],
  ["experience", "Donor and charity experience"],
  ["modules", "Planned modules"],
  ["model", "Business model"],
  ["risk", "Security and risk"],
  ["compliance", "Compliance"],
  ["roadmap", "Roadmap"],
  ["close", "Conclusion"],
];

function PaperPage() {
  return (
    <Shell>
      <article className="mx-auto max-w-3xl px-4 py-10">
        <p className="text-sm font-medium tracking-widest text-blue">WHITEPAPER · VERSION 0.5 DRAFT</p>
        <h1 className="mt-3 font-display text-5xl leading-tight">Verifiable charity on the XRP Ledger</h1>
        <div className="mt-4 h-0.5 w-10 bg-red" aria-hidden />
        <p className="mt-4 text-lg text-muted">Proof comes before payment. Brianne Salato, Founder and Product Architect. October 2026.</p>

        <div className="mt-8">
          <Callout title="How to read this draft">
            The system described here is the intended design. Statements about the XRP Ledger were checked against XRPL.org and Ripple RLUSD documentation. Details marked “to be confirmed” are not yet verified against the specification. This page is a reading copy of that draft, inside the interactive prototype.
          </Callout>
        </div>

        <nav className="mt-8" aria-label="Contents">
          <ol className="grid gap-2 sm:grid-cols-2">
            {TOC.map(([id, label], index) => (
              <li key={id}>
                <a className="text-blue" href={`#${id}`}>
                  {index + 1}. {label}
                </a>
              </li>
            ))}
          </ol>
        </nav>

        <Section id="summary" title="1. Executive summary">
          <p>
            Charitable giving runs on trust, and trust is hard to verify. Donors rarely see what their gift actually bought. Charities carry the burden of proving impact after the money is already spent.
          </p>
          <p>
            VeriChar is a verification layer on the XRP Ledger. Every donation funds one specific, itemized need and is paid in RLUSD. The funds are locked in escrow and released directly to the vendor only when an itemized merchant invoice and cryptographic proof of delivery both verify. The charity never holds the cash. Every step is written to a public ledger.
          </p>
          <p>
            VeriChar is free for donors and charities. It is sustained by a 1% vendor settlement fee and by licensing audit-ready CSR data. Both are designed to be collected on the XRP Ledger.
          </p>
        </Section>

        <Section id="problem" title="2. The problem">
          <p>Opacity: donations are pooled, so a donor cannot trace a specific dollar to a specific purchase.</p>
          <p>Diversion and fraud: unverified organizations, misused funds, and inflated costs are hard to detect when money moves first.</p>
          <p>The burden of proof: honest charities must assemble reports by hand.</p>
          <p>Privacy versus transparency: donors often want both anonymity and proof. Existing platforms usually force a choice.</p>
        </Section>

        <Section id="approach" title="3. The VeriChar approach">
          <p>The order of events changes. Funds are locked first and released only when the evidence exists: donor funds a need, escrow locks on the XRPL, the charity submits invoice and proof, an oracle verifies both, and the vendor is paid directly.</p>
          <p>Charities are checked against an EIN in IRS records, off-ledger, and the wallet is bound to that identity. The XRPL can also link an account to a domain, and Credentials are a possible fit still to be confirmed.</p>
          <p>An escrow names its recipient, here the vendor, when it is created. Finishing it delivers the funds to that recipient. The charity never touches the money.</p>
        </Section>

        <Section id="architecture" title="4. System architecture">
          <p>Four layers, each with one job.</p>
          <p>
            <strong className="font-medium text-ink">Ledger.</strong> Native XRPL escrow, not custom smart-contract code. VeriChar uses a conditional escrow: the only crypto-condition type the ledger supports is PREIMAGE-SHA-256. A conditional escrow with no finish-after time must have an expiry. Every VeriChar escrow carries one, or a failed delivery could lock funds permanently. The oracle must guard the fulfillment, because whoever holds it can release the funds.
          </p>
          <p>
            <strong className="font-medium text-ink">RLUSD.</strong> A USD stablecoin issued as a native token. Trust-line tokens can be escrowed only if the issuer enables Allow Trust Line Locking, and token escrows must always expire. Whether RLUSD itself can be escrowed was not confirmed in the sources reviewed. That is a blocking test before the fee flow can be built on RLUSD.
          </p>
          <p>
            <strong className="font-medium text-ink">Oracle.</strong> Two checks, both required. The supplier log compares the invoice with the funded need. The delivery log inspects photo metadata, a timestamp, and GPS, or accepts a carrier confirmation. This is not the XRPL’s on-ledger price oracle.
          </p>
          <p>
            <strong className="font-medium text-ink">Privacy.</strong> Guests need no VeriChar account, but an XRPL address is still required to send funds. How guest wallets are created and funded is an open design question. A tax-receipt email is encrypted off-chain. A “Stealth Escrow” that weakens the visible link between donor and gift is planned, not built.
          </p>
          <p>
            <strong className="font-medium text-ink">Application.</strong> A donor catalog, a charity portal, and an enterprise CSR dashboard. You are using those three now.
          </p>
        </Section>

        <Section id="proof" title="5. Cryptographic proof, explained">
          <p>A hash is a digital fingerprint: change any detail and the code changes. A signature shows who confirmed a record. A public ledger lets anyone look a validated transaction up by its hash, and recorded data cannot be altered unless a majority of validators agree.</p>
          <p>Which VeriChar proof data is written on-ledger, and whether delivery records are signed with ripple-keypairs, is still to be confirmed. The rule is already fixed: funds release only after the proof is verified.</p>
        </Section>

        <Section id="experience" title="6. Donor and charity experience">
          <p>Donors browse verified charities, fund one item, give as a guest, and watch the status move from funds locked, to proof submitted, to released.</p>
          <p>Charities register with a name, wallet, and EIN, list needs with a price and vendor, and submit the invoice and proof when goods arrive. They pay nothing.</p>
        </Section>

        <Section id="modules" title="7. Planned modules">
          <p>
            <strong className="font-medium text-ink">Subscription escrows.</strong> For baseline goods, a donor can lock a pool. Every 30 days the vault creates a new itemized escrow from updated inventory. Each release still requires both proofs. The sender covers the reserve on every incomplete escrow, so the monthly cycle has to budget for that.
          </p>
          <p>
            <strong className="font-medium text-ink">From Dust to Dreams.</strong> Small leftover balances can be swept into a cause vault and deployed only when a full item is funded. Pooling is meant to spread escrow costs that the documentation warns can make tiny gifts infeasible. Whether it is economical has to be tested.
          </p>
        </Section>

        <Section id="model" title="8. Business model">
          <p>Free for donors and charities. The vendor fee is two conditional escrows, because an escrow has one named recipient: 99% to the vendor and 1% to VeriChar. Both finish only after both proofs pass. If proof never arrives, both expire and the funds return to the sender. A $20 item splits into 19.80 and 0.20.</p>
          <p>An issuer transfer fee is not VeriChar revenue. RLUSD’s issuer is Ripple. If a transfer fee existed it would reduce what recipients receive. The settings reviewed do not list one.</p>
          <p>CSR customers pay the revenue account in RLUSD. A destination tag is the usual way to tell payments apart. VeriChar would credit a subscription only after a validated tesSUCCESS and delivered_amount. Because the raw records are public, the license is the verification and the reporting built on them.</p>
          <p>Revenue is in RLUSD and fees and reserves are in XRP, so the operator must hold an XRP float. Margins cannot be computed from the documentation alone.</p>
        </Section>

        <Section id="risk" title="9. Security and risk">
          <p>Forged invoices are met with parsing, price checks, duplicate detection, a vendor registry, and human review of exceptions. Spoofed photos are met with metadata checks, signed capture, and random audits. Charity-vendor collusion is met with benchmarking and a way to report concerns.</p>
          <p>Oracle compromise is met by guarding fulfillment secrets like keys, with a roadmap toward multiple independent oracles. Lost keys are met by keeping the master key offline, rotating a regular key, and multi-signing high-value accounts. Misread payments are met by counting only validated tesSUCCESS results and delivered_amount, not the Amount field.</p>
          <p>Every escrow gets a CancelAfter. Without it, an escrow never expires and cannot be cancelled. Costs on small gifts will be measured on testnet before minimum sizes are set. Production would run its own xrpld and Clio servers, because a malicious server can misreport payments.</p>
          <p>RLUSD removes most price swing on the gift itself. The issuer can claw back or freeze the token. Whether clawback reaches escrowed RLUSD is not covered by the sources reviewed.</p>
        </Section>

        <Section id="compliance" title="10. Compliance considerations">
          <p>Qualified counsel has to review this before any live launch. Areas called out in the draft: money transmission, charitable solicitation, AML screening, tax treatment of digital assets, data protection, and token or securities rules. Escrow is designed to avoid VeriChar taking custody. That has to be confirmed, not assumed. Charities, not VeriChar, would issue tax receipts.</p>
        </Section>

        <Section id="roadmap" title="11. Roadmap">
          <p>Phase 0, this prototype of the donor flow, charity onboarding, oracle, and release, is the working demo. Phase 1 tests RLUSD conditional escrow with an expiry on the test network, including whether RLUSD can be escrowed at all. Phase 2 is a small pilot after legal and security review. Phase 3 adds subscription escrows, dust pools, multiple oracles, and the enterprise dashboard in production form.</p>
        </Section>

        <Section id="close" title="12. Conclusion">
          <p>Generosity should not require surrendering your common sense. Donors see what the gift bought. Honest charities gain a credible way to prove the work. Vendors are paid promptly. The record belongs to everyone.</p>
          <p>Trust should be enforced by code, not demanded by slogans.</p>
        </Section>

        <footer className="mt-12 border-t border-line pt-6 text-sm text-muted">
          <p>
            About the author: Brianne Salato. VeriChar@proton.me · @VeriCharOnChain · verichar.net
          </p>
          <p className="mt-3">
            This document is for information only and is not legal, financial, tax, or investment advice. It describes planned functionality. VeriChar does not currently process real donations. Nothing here is an offer to sell or a solicitation to buy any asset or security.
          </p>
        </footer>
      </article>
    </Shell>
  );
}

function Section({ id, title, children }: { id: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mt-10 scroll-mt-36">
      <h2 className="font-display text-3xl">{title}</h2>
      <div className="mt-3 h-0.5 w-10 bg-red" aria-hidden />
      <div className="mt-4 space-y-3 text-muted">{children}</div>
    </section>
  );
}
