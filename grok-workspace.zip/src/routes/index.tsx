import { Link, createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Lock, ScanSearch, ShieldCheck, Truck } from "lucide-react";
import { Shell } from "@/components/shell";
import { Callout, SectionTitle, btnQuiet } from "@/components/ui";
import { money, splitAmount } from "@/lib/demo";

export const Route = createFileRoute("/")({
  component: Home,
});

const STEPS = [
  { n: "1", title: "Donor funds a specific need", body: "Not a pooled general fund. One item, one price, one named vendor." },
  { n: "2", title: "Escrow locks funds on the XRPL", body: "A conditional escrow names the vendor up front. The charity never holds the cash." },
  { n: "3", title: "Charity submits invoice and proof", body: "An itemized merchant invoice, plus a photo, a carrier scan, or a signed receipt." },
  { n: "4", title: "Oracle verifies both proofs", body: "Supplier log and delivery log must both pass. The fulfillment stays guarded until then." },
  { n: "5", title: "Vendor paid directly", body: "Finishing the escrow delivers 99% to the vendor and 1% to VeriChar." },
];

const PROBLEMS = [
  {
    title: "Opacity",
    body: "Donations are usually pooled. A donor cannot trace a specific dollar to a specific purchase.",
  },
  {
    title: "Diversion and fraud",
    body: "When money moves first and reports follow later, problems surface only after the damage is done.",
  },
  {
    title: "The burden of proof",
    body: "Honest charities assemble receipts after the fact. The process is slow and hard for an outsider to audit.",
  },
  {
    title: "Privacy versus transparency",
    body: "Many donors want to give without being tracked, and still want proof the gift was used properly.",
  },
];

function Home() {
  const water = splitAmount(20);
  return (
    <Shell>
      <section className="bg-ink text-paper">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 sm:py-20 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <p className="text-sm font-medium tracking-widest text-paper/70">WHITEPAPER · VERSION 0.5</p>
            <h1 className="mt-4 font-display text-5xl leading-tight sm:text-6xl">
              Verifiable charity on the XRP Ledger
            </h1>
            <div className="mt-4 h-0.5 w-10 bg-red" aria-hidden />
            <p className="mt-5 max-w-xl text-lg text-paper/80">
              Proof comes before payment. Every gift funds one itemized need in RLUSD, stays locked in escrow, and
              reaches the vendor only when both proofs verify.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link to="/give" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-paper px-4 py-2 text-sm font-medium text-ink hover:bg-sheet">
                Fund a specific need
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/charity" className="inline-flex min-h-11 items-center justify-center rounded-md border border-paper/30 px-4 py-2 text-sm font-medium text-paper hover:bg-ink-soft">
                Act as a charity
              </Link>
            </div>
          </div>
          <div className="lg:col-span-5">
            <article className="rounded-lg border border-paper/15 bg-ink-soft p-5">
              <p className="text-sm text-paper/70">Example gift · not a live transaction</p>
              <h2 className="mt-2 font-display text-3xl">4 cases of water</h2>
              <p className="mt-1 text-paper/80">Harbor Light Shelter · Boston · Northline Wholesale</p>
              <p className="mt-4 font-display text-4xl tabular-nums">{money(20)} <span className="text-lg">RLUSD</span></p>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-md bg-ink px-3 py-3">
                  <dt className="text-paper/70">Vendor, 99%</dt>
                  <dd className="mt-1 text-lg font-medium tabular-nums">{money(water.vendor)}</dd>
                </div>
                <div className="rounded-md bg-ink px-3 py-3">
                  <dt className="text-paper/70">VeriChar, 1%</dt>
                  <dd className="mt-1 text-lg font-medium tabular-nums">{money(water.fee)}</dd>
                </div>
              </dl>
              <ul className="mt-4 space-y-2 text-sm">
                <li className="flex items-center gap-2"><Lock className="h-4 w-4 text-paper/70" /> Escrow created with an expiry</li>
                <li className="flex items-center gap-2"><ScanSearch className="h-4 w-4 text-paper/70" /> Invoice matched the funded need</li>
                <li className="flex items-center gap-2"><Truck className="h-4 w-4 text-green" /> Delivery proof accepted</li>
                <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-green" /> Vendor paid. Shelter never held the cash.</li>
              </ul>
            </article>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl space-y-16 px-4 py-14">
        <Callout title="Document status">
          This is a working interactive prototype of the Version 0.5 design. It will be tested on the XRP Ledger test
          network, and reviewed by legal and security professionals, before any real funds are handled. Nothing here
          moves RLUSD or XRP.
        </Callout>

        <section>
          <SectionTitle kicker="The problem" title="Giving still asks you to take someone at their word.">
            Four structural gaps follow from paying first and reporting later.
          </SectionTitle>
          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {PROBLEMS.map((problem) => (
              <article key={problem.title} className="rounded-lg border border-line bg-card p-5">
                <h3 className="font-display text-2xl">{problem.title}</h3>
                <p className="mt-2 text-muted">{problem.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section>
          <SectionTitle kicker="The approach" title="Lock the funds first. Release them when the evidence exists." />
          <ol className="mt-8 grid gap-4 lg:grid-cols-5">
            {STEPS.map((step) => (
              <li key={step.n} className="rounded-lg border border-line bg-card p-4">
                <span className={`inline-flex h-8 w-8 items-center justify-center rounded-sm text-sm font-medium ${step.n === "5" ? "bg-green text-paper" : "bg-ink text-paper"}`}>
                  {step.n}
                </span>
                <h3 className="mt-3 font-medium">{step.title}</h3>
                <p className="mt-2 text-sm text-muted">{step.body}</p>
              </li>
            ))}
          </ol>
        </section>

        <section>
          <SectionTitle kicker="Try the prototype" title="Walk a gift from lock to release.">
            The same browser keeps the escrow. Fund an item, submit proof as the charity, then read it on the public ledger.
          </SectionTitle>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <Link to="/give" className="rounded-lg border border-line bg-card p-5 hover:border-blue">
              <p className="text-sm font-medium text-blue">Donor</p>
              <h3 className="mt-2 font-display text-2xl">Fund one item</h3>
              <p className="mt-2 text-sm text-muted">Search by cause, state, or keyword. Give as a guest. A tax-receipt email stays off the ledger.</p>
              <p className={`mt-4 ${btnQuiet}`}>Open the catalog</p>
            </Link>
            <Link to="/charity" className="rounded-lg border border-line bg-card p-5 hover:border-blue">
              <p className="text-sm font-medium text-blue">Charity</p>
              <h3 className="mt-2 font-display text-2xl">Submit both proofs</h3>
              <p className="mt-2 text-sm text-muted">Blankets are already locked. Canned protein is waiting on the oracle. Or register a new EIN.</p>
              <p className={`mt-4 ${btnQuiet}`}>Open the portal</p>
            </Link>
            <Link to="/enterprise" className="rounded-lg border border-line bg-card p-5 hover:border-blue">
              <p className="text-sm font-medium text-blue">Enterprise</p>
              <h3 className="mt-2 font-display text-2xl">Read the CSR record</h3>
              <p className="mt-2 text-sm text-muted">What gets licensed is the verification and the report. The raw ledger is already public.</p>
              <p className={`mt-4 ${btnQuiet}`}>Open the dashboard</p>
            </Link>
          </div>
        </section>

        <section className="grid gap-8 lg:grid-cols-2">
          <div>
            <SectionTitle kicker="Two proofs" title="The rule does not change with the item.">
              A pallet can be proved with a carrier confirmation. A dental visit can be proved with a signed provider record. Funds release only after the proof is verified.
            </SectionTitle>
          </div>
          <div className="grid gap-4">
            <article className="rounded-lg bg-blue-soft p-5">
              <h3 className="font-medium text-blue">Supplier log</h3>
              <p className="mt-2 text-ink">The invoice is read for vendor, line items, and price, then compared with the funded need.</p>
            </article>
            <article className="rounded-lg bg-green-soft p-5">
              <h3 className="font-medium text-green">Delivery log</h3>
              <p className="mt-2 text-ink">A photo is checked for time, place, and a tamper-evident record. Shipped goods can use a carrier confirmation instead.</p>
            </article>
          </div>
        </section>

        <section>
          <SectionTitle kicker="Honest limit" title="A true record is not the same as an honest event." />
          <p className="mt-4 max-w-2xl text-muted">
            Cryptographic proof shows that a record is authentic and unaltered. It cannot prove the underlying event was honest. VeriChar narrows the chance to divert funds and makes fraud easier to see. It does not make fraud impossible.
          </p>
          <p className="mt-6">
            <Link to="/whitepaper" className={btnQuiet}>
              Read the draft whitepaper
              <ArrowRight className="h-4 w-4" />
            </Link>
          </p>
        </section>
      </div>
    </Shell>
  );
}
