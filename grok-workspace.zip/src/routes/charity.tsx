import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/shell";
import { SectionTitle, StatusPill, btnDanger, btnGreen, btnPrimary, btnQuiet } from "@/components/ui";
import {
  CAUSES,
  PROOF_LABEL,
  type Cause,
  type ProofKind,
  money,
} from "@/lib/demo";
import { useDemo } from "@/lib/store";

export const Route = createFileRoute("/charity")({
  component: CharityPage,
  head: () => ({ meta: [{ title: "Charities · VeriChar" }] }),
});

function CharityPage() {
  const charities = useDemo((state) => state.charities);
  const needs = useDemo((state) => state.needs);
  const escrows = useDemo((state) => state.escrows);
  const addCharity = useDemo((state) => state.addCharity);
  const verifyCharity = useDemo((state) => state.verifyCharity);
  const addNeed = useDemo((state) => state.addNeed);

  const verified = charities.filter((charity) => charity.verified);
  const [charityId, setCharityId] = useState("ch-harbor");
  const [mode, setMode] = useState<"portal" | "register">("portal");
  const [notice, setNotice] = useState<string | null>(null);
  const [problem, setProblem] = useState<string | null>(null);

  const [org, setOrg] = useState({ name: "", ein: "", city: "", state: "", cause: "Shelter" as Cause, wallet: "", blurb: "" });
  const [draftNeed, setDraftNeed] = useState({ title: "", price: "", vendor: "", detail: "" });

  const selected = charities.find((charity) => charity.id === charityId) ?? verified[0];
  const queue = escrows.filter(
    (escrow) => escrow.charityId === selected?.id && (escrow.status === "locked" || escrow.status === "proof"),
  );

  function flash(result: { ok: boolean; reason?: string }, okText: string) {
    if (!result.ok) {
      setProblem(result.reason ?? "Something blocked that step.");
      setNotice(null);
      return;
    }
    setProblem(null);
    setNotice(okText);
  }

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <SectionTitle kicker="Charities" title="List the need. Prove the delivery. Never hold the cash.">
          Registration checks the EIN format and binds a wallet. In production the IRS lookup and any XRPL credential happen outside this demo.
        </SectionTitle>

        <div className="mt-6 flex gap-2">
          <button type="button" className={mode === "portal" ? btnPrimary : btnQuiet} onClick={() => setMode("portal")}>
            Act as a charity
          </button>
          <button type="button" className={mode === "register" ? btnPrimary : btnQuiet} onClick={() => setMode("register")}>
            Register
          </button>
        </div>

        {notice ? <p className="mt-4 text-sm text-green">{notice}</p> : null}
        {problem ? <p className="mt-4 text-sm text-red">{problem}</p> : null}

        {mode === "register" ? (
          <form
            className="mt-6 grid max-w-2xl gap-3 rounded-lg border border-line bg-card p-5"
            onSubmit={(event) => {
              event.preventDefault();
              const result = addCharity({ ...org, wallet: org.wallet || "rNewCharitySimulatedVRWn96Dkuk" });
              flash(result, "Registered. Run the EIN check before this organization can list needs.");
              if (result.ok) setCharityId(result.id);
            }}
          >
            <label className="text-sm font-medium">
              Organization
              <input className="field mt-1" value={org.name} onChange={(event) => setOrg({ ...org, name: event.target.value })} required />
            </label>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="text-sm font-medium">
                EIN
                <input className="field mt-1" value={org.ein} placeholder="12-3456789" onChange={(event) => setOrg({ ...org, ein: event.target.value })} required />
              </label>
              <label className="text-sm font-medium">
                Cause
                <select className="field mt-1" value={org.cause} onChange={(event) => setOrg({ ...org, cause: event.target.value as Cause })}>
                  {CAUSES.map((cause) => (
                    <option key={cause}>{cause}</option>
                  ))}
                </select>
              </label>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="text-sm font-medium">
                City
                <input className="field mt-1" value={org.city} onChange={(event) => setOrg({ ...org, city: event.target.value })} />
              </label>
              <label className="text-sm font-medium">
                State
                <input className="field mt-1" maxLength={2} value={org.state} placeholder="MA" onChange={(event) => setOrg({ ...org, state: event.target.value })} />
              </label>
            </div>
            <label className="text-sm font-medium">
              Wallet address
              <input className="field mt-1" value={org.wallet} placeholder="r…" onChange={(event) => setOrg({ ...org, wallet: event.target.value })} />
            </label>
            <label className="text-sm font-medium">
              What you do
              <textarea className="field mt-1" value={org.blurb} onChange={(event) => setOrg({ ...org, blurb: event.target.value })} />
            </label>
            <button type="submit" className={btnPrimary}>Register organization</button>
          </form>
        ) : null}

        {mode === "portal" && selected ? (
          <div className="mt-6 grid gap-6 lg:grid-cols-2">
            <section className="rounded-lg border border-line bg-card p-5">
              <label className="text-sm font-medium">
                Acting as
                <select
                  className="field mt-1"
                  value={selected.id}
                  onChange={(event) => {
                    setCharityId(event.target.value);
                    setNotice(null);
                    setProblem(null);
                  }}
                >
                  {verified.map((charity) => (
                    <option key={charity.id} value={charity.id}>
                      {charity.name}
                    </option>
                  ))}
                </select>
              </label>
              <p className="mt-3 text-sm text-muted">
                {selected.city}, {selected.state} · EIN {selected.ein}
              </p>
              <h2 className="mt-6 font-display text-2xl">Open needs</h2>
              <ul className="mt-2 divide-y divide-line">
                {needs
                  .filter((need) => need.charityId === selected.id)
                  .map((need) => (
                    <li key={need.id} className="flex items-center justify-between gap-3 py-3 text-sm">
                      <span>{need.title}</span>
                      <span className="tabular-nums">{money(need.price)}</span>
                    </li>
                  ))}
              </ul>
              <form
                className="mt-4 grid gap-3"
                onSubmit={(event) => {
                  event.preventDefault();
                  const result = addNeed({
                    charityId: selected.id,
                    title: draftNeed.title,
                    detail: draftNeed.detail,
                    price: Number(draftNeed.price),
                    vendor: draftNeed.vendor,
                    vendorWallet: "rVendorSimulatedVRWn96DkukG4bwd",
                  });
                  flash(result, "Need listed. A donor can fund it from the catalog.");
                  if (result.ok) setDraftNeed({ title: "", price: "", vendor: "", detail: "" });
                }}
              >
                <h3 className="font-medium">List another need</h3>
                <input className="field" placeholder="Item" value={draftNeed.title} onChange={(event) => setDraftNeed({ ...draftNeed, title: event.target.value })} required />
                <div className="grid gap-3 sm:grid-cols-2">
                  <input className="field" placeholder="Price in RLUSD" inputMode="decimal" value={draftNeed.price} onChange={(event) => setDraftNeed({ ...draftNeed, price: event.target.value })} required />
                  <input className="field" placeholder="Vendor to be paid" value={draftNeed.vendor} onChange={(event) => setDraftNeed({ ...draftNeed, vendor: event.target.value })} required />
                </div>
                <input className="field" placeholder="Short detail" value={draftNeed.detail} onChange={(event) => setDraftNeed({ ...draftNeed, detail: event.target.value })} />
                <button type="submit" className={btnQuiet}>List need</button>
                <p className="text-sm text-muted">Gifts under $20 may be uneconomic once real escrow fees are measured. This demo does not charge them.</p>
              </form>
            </section>

            <section className="space-y-4">
              <h2 className="font-display text-2xl">Proof queue</h2>
              {queue.length === 0 ? (
                <p className="rounded-lg border border-line bg-card p-5 text-sm text-muted">
                  Nothing is waiting. When a donor locks a need, it appears here for the invoice and the delivery proof.
                </p>
              ) : (
                queue.map((escrow) => {
                  const need = needs.find((item) => item.id === escrow.needId);
                  if (!need) return null;
                  return (
                    <ProofCard
                      key={escrow.id}
                      escrowId={escrow.id}
                      title={need.title}
                      vendor={need.vendor}
                      price={need.price}
                      city={selected.city}
                      stateCode={selected.state}
                      status={escrow.status}
                      oracleNotes={escrow.oracle?.notes}
                      onDone={(result, okText) => flash(result, okText)}
                    />
                  );
                })
              )}
              {charities.some((charity) => !charity.verified) ? (
                <div className="rounded-lg border border-line bg-card p-5">
                  <h3 className="font-medium">Waiting on the EIN check</h3>
                  <ul className="mt-3 space-y-3">
                    {charities
                      .filter((charity) => !charity.verified)
                      .map((charity) => (
                        <li key={charity.id} className="flex flex-wrap items-center justify-between gap-3 text-sm">
                          <span>
                            {charity.name} · {charity.ein}
                          </span>
                          <button
                            type="button"
                            className={btnQuiet}
                            onClick={() => flash(verifyCharity(charity.id), `${charity.name} is verified in this demo. A production check would use IRS records, off-ledger.`)}
                          >
                            Run EIN check
                          </button>
                        </li>
                      ))}
                  </ul>
                </div>
              ) : null}
            </section>
          </div>
        ) : null}
      </div>
    </Shell>
  );
}

function ProofCard({
  escrowId,
  title,
  vendor,
  price,
  city,
  stateCode,
  status,
  oracleNotes,
  onDone,
}: {
  escrowId: string;
  title: string;
  vendor: string;
  price: number;
  city: string;
  stateCode: string;
  status: "locked" | "proof" | "released" | "cancelled";
  oracleNotes?: string[];
  onDone: (result: { ok: boolean; reason?: string }, okText: string) => void;
}) {
  const submitProof = useDemo((state) => state.submitProof);
  const runOracle = useDemo((state) => state.runOracle);
  const cancelEscrow = useDemo((state) => state.cancelEscrow);
  const [kind, setKind] = useState<ProofKind>("photo");
  const [vendorName, setVendorName] = useState(vendor);
  const [lines, setLines] = useState(title);
  const [total, setTotal] = useState(String(price));
  const [note, setNote] = useState("");
  const [where, setWhere] = useState("");

  function send(
    invoiceVendor: string,
    invoiceLines: string,
    invoiceTotal: number,
    proofNote: string,
    proofWhere: string,
    okText: string,
  ) {
    const result = submitProof(
      escrowId,
      { vendor: invoiceVendor, lines: invoiceLines, total: invoiceTotal },
      { kind, note: proofNote, where: proofWhere },
    );
    if (result.ok) {
      setVendorName(invoiceVendor);
      setLines(invoiceLines);
      setTotal(String(invoiceTotal));
      setNote(proofNote);
      setWhere(proofWhere);
    }
    onDone(result, okText);
  }

  return (
    <article className="rounded-lg border border-line bg-card p-5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h3 className="font-display text-2xl">{title}</h3>
          <p className="text-sm text-muted">
            {vendor} · {money(price)} RLUSD
          </p>
        </div>
        <StatusPill status={status} />
      </div>
      <div className="mt-4 grid gap-3">
        <label className="text-sm font-medium">
          Invoice vendor
          <input className="field mt-1" value={vendorName} onChange={(event) => setVendorName(event.target.value)} />
        </label>
        <label className="text-sm font-medium">
          Line items
          <input className="field mt-1" value={lines} onChange={(event) => setLines(event.target.value)} />
        </label>
        <label className="text-sm font-medium">
          Invoice total
          <input className="field mt-1" inputMode="decimal" value={total} onChange={(event) => setTotal(event.target.value)} />
        </label>
        <label className="text-sm font-medium">
          Proof of delivery
          <select className="field mt-1" value={kind} onChange={(event) => setKind(event.target.value as ProofKind)}>
            {(Object.keys(PROOF_LABEL) as ProofKind[]).map((key) => (
              <option key={key} value={key}>
                {PROOF_LABEL[key]}
              </option>
            ))}
          </select>
        </label>
        <label className="text-sm font-medium">
          What was observed
          <textarea className="field mt-1" value={note} onChange={(event) => setNote(event.target.value)} placeholder="At least 12 characters. Say what arrived and that it matched." />
        </label>
        <label className="text-sm font-medium">
          Where
          <input className="field mt-1" value={where} onChange={(event) => setWhere(event.target.value)} placeholder="City, ST" />
        </label>
      </div>
      <div className="mt-4 flex flex-col gap-2">
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <button
            type="button"
            className={btnQuiet}
            onClick={() =>
              send(
                vendor,
                title,
                price,
                `Delivered to ${city}. Count matched the funded item and the seal was intact.`,
                `${city}, ${stateCode}`,
                "Matching proofs submitted. Run the oracle.",
              )
            }
          >
            Submit a matching pair
          </button>
          <button
            type="button"
            className={btnQuiet}
            onClick={() =>
              send(
                `${vendor} Holdings`,
                title,
                Math.round(price * 140) / 100,
                "Photo of a different shipment. The count was not checked.",
                `${city}, ${stateCode}`,
                "Inflated invoice submitted. Run the oracle to see it held.",
              )
            }
          >
            Submit an inflated invoice
          </button>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <button
            type="button"
            className={btnPrimary}
            onClick={() =>
              send(vendorName, lines, Number(total), note, where, "Your invoice and proof were submitted. Run the oracle.")
            }
          >
            Submit what I typed
          </button>
          <button
            type="button"
            className={btnGreen}
            disabled={status !== "proof"}
            onClick={() => onDone(runOracle(escrowId), "Both proofs passed. Escrow finished and the vendor is paid.")}
          >
            Run oracle
          </button>
          <button
            type="button"
            className={btnDanger}
            onClick={() =>
              onDone(cancelEscrow(escrowId), "Escrow cancelled. After expiry, the design returns the funds to the sender.")
            }
          >
            Cancel escrow
          </button>
        </div>
      </div>
      {oracleNotes && oracleNotes.length > 0 ? (
        <ul className="mt-4 space-y-1 text-sm text-muted">
          {oracleNotes.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
      ) : (
        <p className="mt-4 text-sm text-muted">The oracle checks vendor, price, and a specific delivery note. Both logs must pass.</p>
      )}
    </article>
  );
}
