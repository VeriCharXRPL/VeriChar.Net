import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Shell } from "@/components/shell";
import { SectionTitle } from "@/components/ui";
import { CAUSES, money } from "@/lib/demo";
import { useDemo } from "@/lib/store";

export const Route = createFileRoute("/enterprise")({
  component: EnterprisePage,
  head: () => ({ meta: [{ title: "CSR · VeriChar" }] }),
});

function EnterprisePage() {
  const escrows = useDemo((state) => state.escrows);
  const needs = useDemo((state) => state.needs);
  const charities = useDemo((state) => state.charities);
  const released = escrows.filter((escrow) => escrow.status === "released");
  const open = escrows.filter((escrow) => escrow.status === "locked" || escrow.status === "proof");
  const vendorTotal = released.reduce((sum, escrow) => sum + escrow.vendorShare, 0);
  const feeTotal = released.reduce((sum, escrow) => sum + escrow.feeShare, 0);

  const byCause = CAUSES.map((cause) => {
    const ids = new Set(charities.filter((charity) => charity.cause === cause).map((charity) => charity.id));
    const rows = released.filter((escrow) => ids.has(escrow.charityId));
    return {
      cause,
      released: rows.reduce((sum, escrow) => sum + escrow.vendorShare, 0),
      gifts: rows.length,
    };
  }).filter((row) => row.gifts > 0);

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <SectionTitle kicker="Enterprise" title="The report is the product. The ledger is already public.">
          Companies pay for verification, matching, and a CSR export. They do not pay for secrecy. Raw escrow history can be looked up by anyone.
        </SectionTitle>

        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Paid to vendors" value={money(vendorTotal)} />
          <Stat label="1% settlement fees" value={money(feeTotal)} />
          <Stat label="Gifts released" value={String(released.length)} />
          <Stat label="Still in escrow" value={String(open.length)} />
        </div>

        <section className="mt-8 rounded-lg border border-line bg-card p-5">
          <h2 className="font-display text-2xl">Released to vendors, by cause</h2>
          <p className="mt-1 text-sm text-muted">RLUSD treated as dollars for this draft. Figures update as you finish escrows in the prototype.</p>
          <div className="mt-4 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byCause} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="var(--color-line)" vertical={false} />
                <XAxis dataKey="cause" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} width={40} />
                <Tooltip
                  cursor={{ fill: "var(--color-blue-soft)" }}
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-line)",
                    borderRadius: 12,
                    color: "var(--color-ink)",
                  }}
                  formatter={(value) => [money(Number(value)), "To vendors"]}
                />
                <Bar dataKey="released" fill="var(--color-blue)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>

        <section className="mt-6 overflow-x-auto rounded-lg border border-line bg-card">
          <table className="w-full min-w-[36rem] text-left text-sm">
            <thead className="border-b border-line text-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Gift</th>
                <th className="px-4 py-3 font-medium">Charity</th>
                <th className="px-4 py-3 font-medium">Vendor paid</th>
                <th className="px-4 py-3 font-medium">Proof</th>
              </tr>
            </thead>
            <tbody>
              {released.map((escrow) => {
                const need = needs.find((item) => item.id === escrow.needId);
                const charity = charities.find((item) => item.id === escrow.charityId);
                return (
                  <tr key={escrow.id} className="border-b border-line last:border-b-0">
                    <td className="px-4 py-3">{need?.title}</td>
                    <td className="px-4 py-3">{charity?.name}</td>
                    <td className="px-4 py-3 tabular-nums">{money(escrow.vendorShare)}</td>
                    <td className="px-4 py-3">{escrow.proof ? escrow.proof.kind : "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </section>

        <p className="mt-6 max-w-2xl text-sm text-muted">
          A live subscription would credit only after a validated payment shows tesSUCCESS and delivered_amount. Invoicing in bank currency sits outside the ledger. This dashboard is the shape of that license, with simulated history.
        </p>
      </div>
    </Shell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <article className="rounded-lg border border-line bg-card px-4 py-4">
      <p className="text-sm text-muted">{label}</p>
      <p className="mt-1 font-display text-3xl tabular-nums">{value}</p>
    </article>
  );
}
