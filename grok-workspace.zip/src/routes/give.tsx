import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Shell } from "@/components/shell";
import { SectionTitle, StatusPill, btnGreen, btnPrimary, btnQuiet } from "@/components/ui";
import { CAUSES, type Cause, isFunded, maskEmail, money, splitAmount } from "@/lib/demo";
import { useDemo } from "@/lib/store";

export const Route = createFileRoute("/give")({
  component: GivePage,
  head: () => ({ meta: [{ title: "Give · VeriChar" }] }),
});

function GivePage() {
  const charities = useDemo((state) => state.charities);
  const needs = useDemo((state) => state.needs);
  const escrows = useDemo((state) => state.escrows);
  const fund = useDemo((state) => state.fund);
  const [query, setQuery] = useState("");
  const [cause, setCause] = useState<Cause | "All">("All");
  const [stateCode, setStateCode] = useState("All");
  const [activeId, setActiveId] = useState<string | null>("n-water");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const states = useMemo(
    () => ["All", ...Array.from(new Set(charities.map((charity) => charity.state))).sort()],
    [charities],
  );

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return charities.filter((charity) => {
      if (!charity.verified) return false;
      if (cause !== "All" && charity.cause !== cause) return false;
      if (stateCode !== "All" && charity.state !== stateCode) return false;
      if (!q) return true;
      const blob = [
        charity.name,
        charity.city,
        charity.state,
        charity.cause,
        charity.ein,
        ...needs.filter((need) => need.charityId === charity.id).flatMap((need) => [need.title, need.vendor]),
      ]
        .join(" ")
        .toLowerCase();
      return blob.includes(q);
    });
  }, [charities, needs, query, cause, stateCode]);

  const active = needs.find((need) => need.id === activeId) ?? null;
  const activeCharity = charities.find((charity) => charity.id === active?.charityId);
  const mine = escrows.filter((escrow) => escrow.donorTag === "local");

  function lockFunds() {
    if (!active) return;
    const result = fund(active.id, email);
    if (!result.ok) {
      setError(result.reason);
      setMessage(null);
      return;
    }
    setError(null);
    setMessage("Escrow created. The charity can now submit an invoice and proof of delivery. You gave as a guest on the ledger.");
    setEmail("");
  }

  return (
    <Shell>
      <div className="mx-auto max-w-6xl px-4 py-10">
        <SectionTitle kicker="Donors" title="Fund one itemized need.">
          Browse EIN-verified charities. The price is the gift. Optional email for a tax receipt is kept off the ledger.
        </SectionTitle>

        <form className="mt-8 grid gap-3 sm:grid-cols-3" onSubmit={(event) => event.preventDefault()}>
          <label className="block text-sm font-medium">
            Search
            <input className="field mt-1" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Water, Boston, vendor" />
          </label>
          <label className="block text-sm font-medium">
            Cause
            <select className="field mt-1" value={cause} onChange={(event) => setCause(event.target.value as Cause | "All")}>
              <option>All</option>
              {CAUSES.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </label>
          <label className="block text-sm font-medium">
            State
            <select className="field mt-1" value={stateCode} onChange={(event) => setStateCode(event.target.value)}>
              {states.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </label>
        </form>

        <div className="mt-8 grid gap-8 lg:grid-cols-5">
          <div className="order-2 space-y-6 lg:order-1 lg:col-span-3">
            {visible.length === 0 ? (
              <p className="rounded-lg border border-line bg-card p-5 text-muted">No verified charity matches that search.</p>
            ) : (
              visible.map((charity) => (
                <section key={charity.id} className="rounded-lg border border-line bg-card p-5">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <h2 className="font-display text-2xl">{charity.name}</h2>
                      <p className="mt-1 text-sm text-muted">
                        {charity.city}, {charity.state} · {charity.cause}
                      </p>
                    </div>
                    <span className="rounded-sm bg-green-soft px-2 py-1 text-sm font-medium text-green">EIN {charity.ein}</span>
                  </div>
                  <p className="mt-3 text-sm text-muted">{charity.blurb}</p>
                  <ul className="mt-4 divide-y divide-line">
                    {needs
                      .filter((need) => need.charityId === charity.id)
                      .map((need) => {
                        const taken = isFunded(need.id, escrows);
                        const selected = activeId === need.id;
                        return (
                          <li key={need.id} id={need.id} className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                              <p className="font-medium">{need.title}</p>
                              <p className="text-sm text-muted">{need.vendor}</p>
                            </div>
                            <div className="flex items-center justify-between gap-3 sm:justify-end">
                              <p className="tabular-nums font-medium">{money(need.price)}</p>
                              <button
                                type="button"
                                disabled={taken}
                                onClick={() => {
                                  setActiveId(need.id);
                                  setMessage(null);
                                  setError(null);
                                  document.getElementById("fund-panel")?.scrollIntoView({ behavior: "smooth", block: "start" });
                                }}
                                className={taken ? btnQuiet : selected ? btnPrimary : btnQuiet}
                              >
                                {taken ? "Funded" : selected ? "Selected" : "Fund this"}
                              </button>
                            </div>
                          </li>
                        );
                      })}
                  </ul>
                </section>
              ))
            )}
          </div>

          <aside id="fund-panel" className="order-1 scroll-mt-36 lg:order-2 lg:col-span-2">
            <div className="rounded-lg border border-line bg-card p-5 lg:sticky lg:top-36">
              {active && activeCharity && !isFunded(active.id, escrows) ? (
                <>
                  <p className="text-sm font-medium text-blue">Lock this gift</p>
                  <h2 className="mt-1 font-display text-3xl">{active.title}</h2>
                  <p className="mt-2 text-sm text-muted">
                    {activeCharity.name} · {active.vendor}
                  </p>
                  <p className="mt-4 font-display text-4xl tabular-nums">{money(active.price)}</p>
                  <p className="text-sm text-muted">RLUSD, assuming one dollar. The whitepaper treats that peg as still to be confirmed in production.</p>
                  <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
                    <div className="rounded-md bg-sheet px-3 py-2">
                      <dt className="text-muted">Vendor 99%</dt>
                      <dd className="tabular-nums font-medium">{money(splitAmount(active.price).vendor)}</dd>
                    </div>
                    <div className="rounded-md bg-sheet px-3 py-2">
                      <dt className="text-muted">Fee 1%</dt>
                      <dd className="tabular-nums font-medium">{money(splitAmount(active.price).fee)}</dd>
                    </div>
                  </dl>
                  <label className="mt-4 block text-sm font-medium">
                    Email for a tax receipt, optional
                    <input
                      className="field mt-1"
                      type="email"
                      autoComplete="email"
                      value={email}
                      placeholder="Leave blank to stay a guest"
                      onChange={(event) => setEmail(event.target.value)}
                    />
                  </label>
                  <p className="mt-2 text-sm text-muted">If you add an email, this prototype keeps it in the browser only. It is never written on the public ledger.</p>
                  <button type="button" className={`${btnGreen} mt-4 w-full`} onClick={lockFunds}>
                    Lock funds in escrow
                  </button>
                </>
              ) : (
                <>
                  <p className="text-sm font-medium text-blue">Choose an open item</p>
                  <p className="mt-2 text-muted">Funded items stay locked until proof clears or the escrow is cancelled and the gift returns to the donor.</p>
                </>
              )}
              {error ? <p className="mt-3 text-sm text-red">{error}</p> : null}
              {message ? <p className="mt-3 text-sm text-green">{message}</p> : null}
            </div>

            <section className="mt-4 rounded-lg border border-line bg-card p-5">
              <h2 className="font-medium">Your gifts in this browser</h2>
              {mine.length === 0 ? (
                <p className="mt-2 text-sm text-muted">None yet. The water case at Harbor Light is the whitepaper’s example.</p>
              ) : (
                <ul className="mt-3 space-y-3">
                  {mine.map((escrow) => {
                    const need = needs.find((item) => item.id === escrow.needId);
                    return (
                      <li key={escrow.id} className="flex items-start justify-between gap-3 text-sm">
                        <div>
                          <p className="font-medium">{need?.title}</p>
                          <p className="text-muted">
                            {escrow.receiptEmail ? `Receipt ${maskEmail(escrow.receiptEmail)}` : "Guest · no receipt email"}
                          </p>
                        </div>
                        <StatusPill status={escrow.status} />
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>
          </aside>
        </div>
      </div>
    </Shell>
  );
}
