export type Cause = "Shelter" | "Food" | "Health" | "Disaster" | "Hygiene";

export type Charity = {
  id: string;
  name: string;
  ein: string;
  city: string;
  state: string;
  cause: Cause;
  wallet: string;
  blurb: string;
  verified: boolean;
};

export type Need = {
  id: string;
  charityId: string;
  title: string;
  detail: string;
  price: number;
  vendor: string;
  vendorWallet: string;
};

export type ProofKind = "photo" | "carrier" | "receipt";

export type Invoice = {
  vendor: string;
  lines: string;
  total: number;
};

export type DeliveryProof = {
  kind: ProofKind;
  note: string;
  where: string;
};

export type EscrowStatus = "locked" | "proof" | "released" | "cancelled";

export type OracleResult = {
  invoiceOk: boolean;
  deliveryOk: boolean;
  notes: string[];
};

export type Escrow = {
  id: string;
  needId: string;
  charityId: string;
  donorTag: "local" | "archive";
  receiptEmail?: string;
  amount: number;
  vendorShare: number;
  feeShare: number;
  status: EscrowStatus;
  createdAt: number;
  finishedAt?: number;
  invoice?: Invoice;
  proof?: DeliveryProof;
  oracle?: OracleResult;
  txCreate: string;
  txFinish?: string;
  txCancel?: string;
};

export const CAUSES: Cause[] = ["Shelter", "Food", "Health", "Disaster", "Hygiene"];

export const PROOF_LABEL: Record<ProofKind, string> = {
  photo: "Time-stamped photo with GPS",
  carrier: "Carrier delivery confirmation",
  receipt: "Signed provider receipt",
};

export function splitAmount(amount: number) {
  const cents = Math.round(amount * 100);
  const feeCents = Math.round(cents * 0.01);
  return {
    fee: feeCents / 100,
    vendor: (cents - feeCents) / 100,
  };
}

export function money(amount: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(amount);
}

export function fakeHash(seed: string) {
  let x = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    x ^= seed.charCodeAt(i);
    x = Math.imul(x, 16777619);
  }
  let out = "";
  for (let i = 0; i < 8; i++) {
    x = Math.imul(x ^ (x >>> 13), 1274126177) >>> 0;
    out += x.toString(16).padStart(8, "0");
  }
  return out;
}

export function shortHash(hash: string) {
  return `${hash.slice(0, 8)}…${hash.slice(-6)}`;
}

export function maskEmail(email: string) {
  const [user, domain] = email.split("@");
  if (!user || !domain) return "requested";
  return `${user.slice(0, 1)}•••@${domain}`;
}

export function norm(value: string) {
  return value.trim().toLowerCase().replace(/\s+/g, " ");
}

export function formatWhen(ts: number) {
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(ts);
}

function escrowBase(
  partial: Pick<Escrow, "id" | "needId" | "charityId" | "amount" | "status" | "createdAt"> &
    Partial<Escrow>,
): Escrow {
  const parts = splitAmount(partial.amount);
  return {
    donorTag: "archive",
    vendorShare: parts.vendor,
    feeShare: parts.fee,
    txCreate: fakeHash(`${partial.id}:create`),
    ...partial,
  };
}

export function createSeed() {
  const charities: Charity[] = [
    {
      id: "ch-harbor",
      name: "Harbor Light Shelter",
      ein: "04-3182204",
      city: "Boston",
      state: "MA",
      cause: "Shelter",
      wallet: "rHb9HarborLight4rj91VRWn96DkukG4bw",
      blurb: "Overnight beds and a supply closet that is restocked only when a donor funds a listed item.",
      verified: true,
    },
    {
      id: "ch-rio",
      name: "Rio Mesa Food Bank",
      ein: "74-2209183",
      city: "Austin",
      state: "TX",
      cause: "Food",
      wallet: "rRioMesaFoodBank91VRWn96DkukG4bwd",
      blurb: "A pantry that buys rice, protein, and produce from named wholesalers. No general fund.",
      verified: true,
    },
    {
      id: "ch-molar",
      name: "Bright Molar Kids Clinic",
      ein: "86-4419027",
      city: "Phoenix",
      state: "AZ",
      cause: "Health",
      wallet: "rBrightMolarKids86VRWn96DkukG4bwdty",
      blurb: "Pediatric dental visits for families without coverage. The clinic is the vendor and is paid directly.",
      verified: true,
    },
    {
      id: "ch-lake",
      name: "Lakeshore Family House",
      ein: "36-2901148",
      city: "Chicago",
      state: "IL",
      cause: "Hygiene",
      wallet: "rLakeshoreFamily36VRWn96DkukG4bwdt",
      blurb: "Family rooms for people leaving unsafe housing. Baseline goods can later move to a monthly subscription escrow.",
      verified: true,
    },
    {
      id: "ch-tide",
      name: "Tidewater Relief",
      ein: "54-7712033",
      city: "Norfolk",
      state: "VA",
      cause: "Disaster",
      wallet: "rTidewaterRelief54VRWn96DkukG4bwdty",
      blurb: "Storm response supplies shipped to a verified warehouse, then proved with a carrier confirmation.",
      verified: true,
    },
  ];

  const needs: Need[] = [
    {
      id: "n-water",
      charityId: "ch-harbor",
      title: "4 cases of drinking water",
      detail: "The worked example from the whitepaper. One donor funds this exact item.",
      price: 20,
      vendor: "Northline Wholesale",
      vendorWallet: "rNorthlineWholesaleVRWn96DkukG4b",
    },
    {
      id: "n-kits",
      charityId: "ch-harbor",
      title: "20 hygiene kits",
      detail: "Soap, toothpaste, and a towel, packed for new arrivals.",
      price: 86,
      vendor: "CleanStart Supply",
      vendorWallet: "rCleanStartSupplyVRWn96DkukG4bw",
    },
    {
      id: "n-blankets",
      charityId: "ch-harbor",
      title: "12 wool blankets",
      detail: "Waiting on the shelter to submit the merchant invoice and a delivery photo.",
      price: 144,
      vendor: "Hearth Textile Co.",
      vendorWallet: "rHearthTextileCoVRWn96DkukG4bwd",
    },
    {
      id: "n-rice",
      charityId: "ch-rio",
      title: "40 lb of rice",
      detail: "A staple sack for the week’s pantry build.",
      price: 32,
      vendor: "Gulf Grain Co-op",
      vendorWallet: "rGulfGrainCoopVRWn96DkukG4bwdty",
    },
    {
      id: "n-cans",
      charityId: "ch-rio",
      title: "Case of canned protein",
      detail: "Invoice and carrier confirmation are in. The oracle has not run yet.",
      price: 48,
      vendor: "Pantry Line Foods",
      vendorWallet: "rPantryLineFoodsVRWn96DkukG4bwd",
    },
    {
      id: "n-clean",
      charityId: "ch-molar",
      title: "Pediatric cleaning",
      detail: "One appointment. Proof was a signed provider record.",
      price: 75,
      vendor: "Bright Molar Clinic",
      vendorWallet: "rBrightMolarClinicVRWn96DkukG4b",
    },
    {
      id: "n-seal",
      charityId: "ch-molar",
      title: "Sealants for 6 children",
      detail: "A kit plus chair time. The provider is paid only after the signed record.",
      price: 120,
      vendor: "Bright Molar Clinic",
      vendorWallet: "rBrightMolarClinicVRWn96DkukG4b",
    },
    {
      id: "n-diaper",
      charityId: "ch-lake",
      title: "Diapers, size 4, one pallet",
      detail: "Baseline stock. A future module would renew this every 30 days.",
      price: 210,
      vendor: "Little Steps Wholesale",
      vendorWallet: "rLittleStepsWholesaleVRWn96Dkuk",
    },
    {
      id: "n-formula",
      charityId: "ch-lake",
      title: "Infant formula, 8 cases",
      detail: "Released to the wholesaler after the delivery photo matched the dock.",
      price: 96,
      vendor: "Hearthwell Nutrition",
      vendorWallet: "rHearthwellNutritionVRWn96DkukG",
    },
    {
      id: "n-tarp",
      charityId: "ch-tide",
      title: "Emergency tarp kits × 10",
      detail: "Still open. Built for a fast merchant order once a donor locks the price.",
      price: 150,
      vendor: "Shoreline Field Supply",
      vendorWallet: "rShorelineFieldSupplyVRWn96Dkuk",
    },
    {
      id: "n-tabs",
      charityId: "ch-tide",
      title: "Water purification tablets",
      detail: "A small gift that still cleared the two-proof rule.",
      price: 28,
      vendor: "ClearCurrent Labs",
      vendorWallet: "rClearCurrentLabsVRWn96DkukG4bw",
    },
  ];

  const escrows: Escrow[] = [
    escrowBase({
      id: "esc-kits",
      needId: "n-kits",
      charityId: "ch-harbor",
      amount: 86,
      status: "released",
      createdAt: Date.parse("2026-10-02T15:00:00Z"),
      finishedAt: Date.parse("2026-10-04T18:10:00Z"),
      txFinish: fakeHash("esc-kits:finish"),
      invoice: {
        vendor: "CleanStart Supply",
        lines: "20 hygiene kits",
        total: 86,
      },
      proof: {
        kind: "photo",
        note: "Dock photo at Harbor Light, GPS matched the shelter, cartons sealed.",
        where: "Boston, MA",
      },
      oracle: {
        invoiceOk: true,
        deliveryOk: true,
        notes: ["Vendor, line, and price matched the funded need.", "Photo metadata accepted."],
      },
    }),
    escrowBase({
      id: "esc-rice",
      needId: "n-rice",
      charityId: "ch-rio",
      amount: 32,
      status: "released",
      createdAt: Date.parse("2026-10-04T15:00:00Z"),
      finishedAt: Date.parse("2026-10-05T16:00:00Z"),
      txFinish: fakeHash("esc-rice:finish"),
      invoice: { vendor: "Gulf Grain Co-op", lines: "40 lb rice", total: 32 },
      proof: {
        kind: "carrier",
        note: "Carrier marked delivered to the pantry loading door.",
        where: "Austin, TX",
      },
      oracle: {
        invoiceOk: true,
        deliveryOk: true,
        notes: ["Invoice matched.", "Carrier confirmation accepted."],
      },
    }),
    escrowBase({
      id: "esc-clean",
      needId: "n-clean",
      charityId: "ch-molar",
      amount: 75,
      status: "released",
      createdAt: Date.parse("2026-10-06T15:00:00Z"),
      finishedAt: Date.parse("2026-10-06T21:00:00Z"),
      txFinish: fakeHash("esc-clean:finish"),
      invoice: { vendor: "Bright Molar Clinic", lines: "Pediatric cleaning", total: 75 },
      proof: {
        kind: "receipt",
        note: "Provider signed the visit record after the cleaning.",
        where: "Phoenix, AZ",
      },
      oracle: {
        invoiceOk: true,
        deliveryOk: true,
        notes: ["Provider and price matched.", "Signed record accepted."],
      },
    }),
    escrowBase({
      id: "esc-formula",
      needId: "n-formula",
      charityId: "ch-lake",
      amount: 96,
      status: "released",
      createdAt: Date.parse("2026-10-08T15:00:00Z"),
      finishedAt: Date.parse("2026-10-09T17:30:00Z"),
      txFinish: fakeHash("esc-formula:finish"),
      invoice: { vendor: "Hearthwell Nutrition", lines: "Infant formula, 8 cases", total: 96 },
      proof: {
        kind: "photo",
        note: "Cases photographed in the family-house storeroom.",
        where: "Chicago, IL",
      },
      oracle: {
        invoiceOk: true,
        deliveryOk: true,
        notes: ["Invoice matched.", "Storeroom photo accepted."],
      },
    }),
    escrowBase({
      id: "esc-tabs",
      needId: "n-tabs",
      charityId: "ch-tide",
      amount: 28,
      status: "released",
      createdAt: Date.parse("2026-10-09T15:00:00Z"),
      finishedAt: Date.parse("2026-10-10T14:00:00Z"),
      txFinish: fakeHash("esc-tabs:finish"),
      invoice: { vendor: "ClearCurrent Labs", lines: "Purification tablets", total: 28 },
      proof: {
        kind: "carrier",
        note: "Carrier scan at the Norfolk warehouse.",
        where: "Norfolk, VA",
      },
      oracle: {
        invoiceOk: true,
        deliveryOk: true,
        notes: ["Invoice matched.", "Carrier scan accepted."],
      },
    }),
    escrowBase({
      id: "esc-blankets",
      needId: "n-blankets",
      charityId: "ch-harbor",
      amount: 144,
      status: "locked",
      createdAt: Date.parse("2026-10-12T15:00:00Z"),
    }),
    escrowBase({
      id: "esc-cans",
      needId: "n-cans",
      charityId: "ch-rio",
      amount: 48,
      status: "proof",
      createdAt: Date.parse("2026-10-13T15:00:00Z"),
      invoice: {
        vendor: "Pantry Line Foods",
        lines: "1 case canned protein",
        total: 48,
      },
      proof: {
        kind: "carrier",
        note: "Delivered to Rio Mesa Food Bank, dock 2, signed by the pantry lead.",
        where: "Austin, TX",
      },
    }),
  ];

  return { charities, needs, escrows };
}

export function isFunded(needId: string, escrows: Escrow[]) {
  return escrows.some((escrow) => escrow.needId === needId && escrow.status !== "cancelled");
}
