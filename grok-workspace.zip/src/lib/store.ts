import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  type Charity,
  type DeliveryProof,
  type Escrow,
  type Invoice,
  type Need,
  createSeed,
  fakeHash,
  isFunded,
  norm,
  splitAmount,
} from "@/lib/demo";

type FundResult = { ok: true; id: string } | { ok: false; reason: string };

type DemoState = {
  charities: Charity[];
  needs: Need[];
  escrows: Escrow[];
  fund: (needId: string, email: string) => FundResult;
  addCharity: (input: Omit<Charity, "id" | "verified">) => FundResult;
  verifyCharity: (id: string) => FundResult;
  addNeed: (input: Omit<Need, "id">) => FundResult;
  submitProof: (escrowId: string, invoice: Invoice, proof: DeliveryProof) => FundResult;
  runOracle: (escrowId: string) => FundResult;
  cancelEscrow: (escrowId: string) => FundResult;
  reset: () => void;
};

const memoryStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

const storage = createJSONStorage(() =>
  typeof window === "undefined" ? memoryStorage : window.localStorage,
);

function judge(need: Need, invoice: Invoice, proof: DeliveryProof) {
  const invoiceOk = norm(invoice.vendor) === norm(need.vendor) && Math.abs(invoice.total - need.price) < 0.001;
  const deliveryOk = proof.note.trim().length >= 12 && proof.where.trim().length >= 2;
  const notes: string[] = [];
  notes.push(
    norm(invoice.vendor) === norm(need.vendor)
      ? "Supplier log: vendor name matches the funded need."
      : `Supplier log: invoice vendor “${invoice.vendor}” does not match “${need.vendor}”.`,
  );
  notes.push(
    Math.abs(invoice.total - need.price) < 0.001
      ? "Supplier log: invoice total matches the locked price."
      : "Supplier log: invoice total does not match the locked price.",
  );
  notes.push(
    deliveryOk
      ? "Delivery log: proof note and place are specific enough to accept in this prototype."
      : "Delivery log: add a specific note (12+ characters) and where it was delivered.",
  );
  return { invoiceOk, deliveryOk, notes };
}

export const useDemo = create<DemoState>()(
  persist(
    (set, get) => ({
      ...createSeed(),
      fund: (needId, email) => {
        const { needs, charities, escrows } = get();
        const need = needs.find((item) => item.id === needId);
        if (!need) return { ok: false, reason: "That need is no longer listed." };
        const charity = charities.find((item) => item.id === need.charityId);
        if (!charity?.verified) return { ok: false, reason: "This charity is not verified yet." };
        if (isFunded(needId, escrows)) return { ok: false, reason: "This item already has an active escrow." };
        const receiptEmail = email.trim();
        if (receiptEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(receiptEmail)) {
          return { ok: false, reason: "Enter a valid email, or leave it blank to give as a guest." };
        }
        const id = `esc-${Date.now().toString(36)}`;
        const parts = splitAmount(need.price);
        const escrow: Escrow = {
          id,
          needId,
          charityId: need.charityId,
          donorTag: "local",
          receiptEmail: receiptEmail || undefined,
          amount: need.price,
          vendorShare: parts.vendor,
          feeShare: parts.fee,
          status: "locked",
          createdAt: Date.now(),
          txCreate: fakeHash(`${id}:create`),
        };
        set({ escrows: [escrow, ...escrows] });
        return { ok: true, id };
      },
      addCharity: (input) => {
        const ein = input.ein.trim();
        if (!/^\d{2}-?\d{7}$/.test(ein)) {
          return { ok: false, reason: "Use an EIN like 12-3456789. The real IRS check happens off-ledger." };
        }
        if (input.name.trim().length < 3) return { ok: false, reason: "Enter the organization’s name." };
        if (input.wallet.trim().length < 8) return { ok: false, reason: "Enter the charity wallet address." };
        const formatted = ein.includes("-") ? ein : `${ein.slice(0, 2)}-${ein.slice(2)}`;
        if (get().charities.some((item) => item.ein === formatted)) {
          return { ok: false, reason: "That EIN is already on the list." };
        }
        const id = `ch-${Date.now().toString(36)}`;
        const charity: Charity = {
          ...input,
          id,
          ein: formatted,
          name: input.name.trim(),
          city: input.city.trim() || "Unlisted",
          state: input.state.trim().toUpperCase().slice(0, 2) || "—",
          wallet: input.wallet.trim(),
          blurb: input.blurb.trim() || "Newly registered in this prototype. Not yet verified.",
          verified: false,
        };
        set({ charities: [charity, ...get().charities] });
        return { ok: true, id };
      },
      verifyCharity: (id) => {
        const charity = get().charities.find((item) => item.id === id);
        if (!charity) return { ok: false, reason: "Charity not found." };
        if (!/^\d{2}-\d{7}$/.test(charity.ein)) {
          return { ok: false, reason: "EIN format is not valid." };
        }
        set({
          charities: get().charities.map((item) =>
            item.id === id ? { ...item, verified: true, blurb: item.blurb.replace("Not yet verified.", "EIN format accepted in this demo.") } : item,
          ),
        });
        return { ok: true, id };
      },
      addNeed: (input) => {
        const charity = get().charities.find((item) => item.id === input.charityId);
        if (!charity?.verified) return { ok: false, reason: "Verify the charity before listing a need." };
        if (input.title.trim().length < 3) return { ok: false, reason: "Name the item." };
        if (input.vendor.trim().length < 2) return { ok: false, reason: "Name the vendor who will be paid." };
        if (!Number.isFinite(input.price) || input.price <= 0) return { ok: false, reason: "Enter a price in RLUSD." };
        const id = `need-${Date.now().toString(36)}`;
        const need: Need = {
          ...input,
          id,
          title: input.title.trim(),
          detail: input.detail.trim() || "Listed by the charity in this prototype.",
          vendor: input.vendor.trim(),
          vendorWallet: input.vendorWallet.trim() || "rVendorSimulatedVRWn96DkukG4bwd",
          price: Math.round(input.price * 100) / 100,
        };
        set({ needs: [need, ...get().needs] });
        return { ok: true, id };
      },
      submitProof: (escrowId, invoice, proof) => {
        const escrow = get().escrows.find((item) => item.id === escrowId);
        if (!escrow || (escrow.status !== "locked" && escrow.status !== "proof")) {
          return { ok: false, reason: "This escrow is not open for proof." };
        }
        if (!invoice.vendor.trim() || !invoice.lines.trim()) {
          return { ok: false, reason: "The invoice needs a vendor and a line description." };
        }
        if (!Number.isFinite(invoice.total)) return { ok: false, reason: "Enter the invoice total." };
        set({
          escrows: get().escrows.map((item) =>
            item.id === escrowId
              ? {
                  ...item,
                  status: "proof",
                  invoice: {
                    vendor: invoice.vendor.trim(),
                    lines: invoice.lines.trim(),
                    total: Math.round(invoice.total * 100) / 100,
                  },
                  proof: {
                    kind: proof.kind,
                    note: proof.note.trim(),
                    where: proof.where.trim(),
                  },
                  oracle: undefined,
                }
              : item,
          ),
        });
        return { ok: true, id: escrowId };
      },
      runOracle: (escrowId) => {
        const { escrows, needs } = get();
        const escrow = escrows.find((item) => item.id === escrowId);
        const need = needs.find((item) => item.id === escrow?.needId);
        if (!escrow || !need || escrow.status !== "proof" || !escrow.invoice || !escrow.proof) {
          return { ok: false, reason: "Submit both proofs before the oracle can run." };
        }
        const oracle = judge(need, escrow.invoice, escrow.proof);
        const passed = oracle.invoiceOk && oracle.deliveryOk;
        set({
          escrows: escrows.map((item) =>
            item.id === escrowId
              ? {
                  ...item,
                  oracle,
                  status: passed ? "released" : "proof",
                  finishedAt: passed ? Date.now() : undefined,
                  txFinish: passed ? fakeHash(`${escrowId}:finish`) : undefined,
                }
              : item,
          ),
        });
        return passed
          ? { ok: true, id: escrowId }
          : { ok: false, reason: "The oracle held the escrow. Fix the invoice or the delivery proof." };
      },
      cancelEscrow: (escrowId) => {
        const escrow = get().escrows.find((item) => item.id === escrowId);
        if (!escrow || escrow.status === "released" || escrow.status === "cancelled") {
          return { ok: false, reason: "This escrow can no longer be cancelled." };
        }
        set({
          escrows: get().escrows.map((item) =>
            item.id === escrowId
              ? { ...item, status: "cancelled", finishedAt: Date.now(), txCancel: fakeHash(`${escrowId}:cancel`) }
              : item,
          ),
        });
        return { ok: true, id: escrowId };
      },
      reset: () => set(createSeed()),
    }),
    {
      name: "verichar-demo",
      version: 1,
      skipHydration: true,
      storage,
      partialize: (state) => ({
        charities: state.charities,
        needs: state.needs,
        escrows: state.escrows,
      }),
    },
  ),
);
