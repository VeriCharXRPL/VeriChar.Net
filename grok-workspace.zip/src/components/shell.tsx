import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { useDemo } from "@/lib/store";

const LINKS = [
  { to: "/give", label: "Give" },
  { to: "/charity", label: "Charities" },
  { to: "/ledger", label: "Ledger" },
  { to: "/enterprise", label: "CSR" },
  { to: "/whitepaper", label: "Whitepaper" },
] as const;

function Mark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <path
        d="M10 14 L32 54 L54 14"
        fill="none"
        stroke="currentColor"
        strokeWidth="9"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
      <path
        d="M38 18 L46 28 L60 10"
        fill="none"
        stroke="currentColor"
        className="text-green"
        strokeWidth="6"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function Logo({ inverse = false }: { inverse?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-2 ${inverse ? "text-paper" : "text-ink"}`}>
      <Mark className="h-8 w-8" />
      <span className="font-display text-2xl leading-none">
        VeriChar<span className="text-green">.net</span>
      </span>
    </span>
  );
}

export function Shell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const waiting = useDemo((state) =>
    state.escrows.filter((escrow) => escrow.status === "locked" || escrow.status === "proof").length,
  );
  const reset = useDemo((state) => state.reset);

  useEffect(() => {
    void useDemo.persist.rehydrate();
  }, []);

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-20 border-b border-line bg-paper/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
          <Link to="/" aria-label="VeriChar home">
            <Logo />
          </Link>
          <p className="hidden text-sm text-muted sm:block">Prototype · no real funds</p>
        </div>
        <nav className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 pb-3" aria-label="Primary">
          {LINKS.map((link) => {
            const on = pathname === link.to;
            return (
              <Link
                key={link.to}
                to={link.to}
                className={`inline-flex min-h-11 shrink-0 items-center gap-2 rounded-md px-3 text-sm font-medium ${
                  on ? "bg-ink text-paper" : "text-ink hover:bg-sheet"
                }`}
              >
                {link.label}
                {link.to === "/charity" && waiting > 0 ? (
                  <span className={`rounded-sm px-1.5 tabular-nums ${on ? "bg-paper text-ink" : "bg-blue-soft text-blue"}`}>
                    {waiting}
                  </span>
                ) : null}
              </Link>
            );
          })}
        </nav>
        <p className="px-4 pb-3 text-sm text-muted sm:hidden">Prototype · no real funds</p>
      </header>
      <main>{children}</main>
      <footer className="mt-16 border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-8 text-sm text-muted sm:flex-row sm:items-end sm:justify-between">
          <div className="max-w-xl">
            <p className="font-medium text-ink">Brianne Salato, Founder and Product Architect</p>
            <p className="mt-1">
              Version 0.5 draft · October 2026. This demo does not process real donations. It is not legal, financial, tax, or
              investment advice.
            </p>
          </div>
          <button type="button" onClick={reset} className="min-h-11 text-left font-medium text-blue">
            Reset prototype data
          </button>
        </div>
      </footer>
    </div>
  );
}
