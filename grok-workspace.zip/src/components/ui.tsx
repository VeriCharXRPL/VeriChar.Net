import type { EscrowStatus } from "@/lib/demo";

const STATUS_LABEL: Record<EscrowStatus, string> = {
  locked: "Funds locked",
  proof: "Proof submitted",
  released: "Vendor paid",
  cancelled: "Returned to donor",
};

const STATUS_CLASS: Record<EscrowStatus, string> = {
  locked: "bg-blue-soft text-blue",
  proof: "bg-sheet text-ink",
  released: "bg-green-soft text-green",
  cancelled: "bg-red-soft text-red",
};

export function StatusPill({ status }: { status: EscrowStatus }) {
  return (
    <span className={`inline-flex min-h-7 items-center rounded-sm px-2 text-sm font-medium ${STATUS_CLASS[status]}`}>
      {STATUS_LABEL[status]}
    </span>
  );
}

export function SectionTitle({
  kicker,
  title,
  children,
}: {
  kicker?: string;
  title: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="max-w-2xl">
      {kicker ? <p className="text-sm font-medium text-blue">{kicker}</p> : null}
      <h2 className="mt-1 font-display text-3xl text-ink sm:text-4xl">{title}</h2>
      <div className="mt-3 h-0.5 w-10 bg-red" aria-hidden />
      {children ? <p className="mt-4 text-muted">{children}</p> : null}
    </div>
  );
}

export function Callout({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <aside className="border-l-4 border-red bg-card px-5 py-4">
      <p className="font-medium text-ink">{title}</p>
      <div className="mt-1 text-muted">{children}</div>
    </aside>
  );
}

export const btnPrimary =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-blue px-4 py-2 text-sm font-medium text-paper transition-colors duration-200 hover:bg-ink disabled:cursor-not-allowed disabled:opacity-50";

export const btnQuiet =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-line bg-card px-4 py-2 text-sm font-medium text-ink transition-colors duration-200 hover:bg-sheet disabled:cursor-not-allowed disabled:opacity-50";

export const btnGreen =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-green px-4 py-2 text-sm font-medium text-paper transition-colors duration-200 hover:bg-ink disabled:cursor-not-allowed disabled:opacity-50";

export const btnDanger =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border border-red bg-card px-4 py-2 text-sm font-medium text-red transition-colors duration-200 hover:bg-red-soft disabled:cursor-not-allowed disabled:opacity-50";
